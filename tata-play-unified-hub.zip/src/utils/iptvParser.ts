import { Channel } from '../types';

/**
 * Parses raw M3U / M3U8 text content into strongly-typed Channel array
 */
export function parseM3u(content: string, _playlistName: string = 'Imported Playlist'): Channel[] {
  const lines = content.split(/\r?\n/);
  const channels: Channel[] = [];

  let currentMeta: {
    name: string;
    tvgId?: string;
    tvgName?: string;
    tvgLogo?: string;
    groupTitle?: string;
    channelNumber?: number;
  } | null = null;

  let fallbackNumber = 1;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    if (line.startsWith('#EXTINF:')) {
      // Parse EXTINF line
      // Format: #EXTINF:-1 tvg-id="xyz" tvg-name="XYZ" tvg-logo="url" group-title="Group",Channel Name
      const commaIndex = line.lastIndexOf(',');
      let rawAttributes = '';
      let channelName = 'Channel ' + fallbackNumber;

      if (commaIndex !== -1) {
        rawAttributes = line.substring(8, commaIndex);
        channelName = line.substring(commaIndex + 1).trim() || channelName;
      } else {
        rawAttributes = line.substring(8);
      }

      // Extract attributes using regex
      const tvgIdMatch = rawAttributes.match(/tvg-id=["']([^"']*)["']/i);
      const tvgNameMatch = rawAttributes.match(/tvg-name=["']([^"']*)["']/i);
      const tvgLogoMatch = rawAttributes.match(/tvg-logo=["']([^"']*)["']/i);
      const groupTitleMatch = rawAttributes.match(/group-title=["']([^"']*)["']/i);
      const chnoMatch = rawAttributes.match(/tvg-chno=["']([^"']*)["']/i) || rawAttributes.match(/channel-id=["']([^"']*)["']/i);

      let channelNumber = fallbackNumber;
      if (chnoMatch && !isNaN(parseInt(chnoMatch[1], 10))) {
        channelNumber = parseInt(chnoMatch[1], 10);
      }

      currentMeta = {
        name: channelName,
        tvgId: tvgIdMatch ? tvgIdMatch[1] : undefined,
        tvgName: tvgNameMatch ? tvgNameMatch[1] : undefined,
        tvgLogo: tvgLogoMatch ? tvgLogoMatch[1] : undefined,
        groupTitle: groupTitleMatch ? groupTitleMatch[1] : 'General',
        channelNumber,
      };
    } else if (!line.startsWith('#') && currentMeta) {
      // This is the stream URL
      const streamUrl = line.trim();
      if (streamUrl.startsWith('http://') || streamUrl.startsWith('https://') || streamUrl.startsWith('rtmp://')) {
        const is4K = currentMeta.name.toUpperCase().includes('4K') || currentMeta.name.toUpperCase().includes('UHD');
        const isHD = is4K || currentMeta.name.toUpperCase().includes('HD') || currentMeta.name.toUpperCase().includes('FHD');

        // Detect stream format
        let streamFormat: 'hls' | 'ts' | 'mp4' | 'auto' = 'auto';
        const urlLower = streamUrl.toLowerCase();
        if (urlLower.includes('.m3u8')) {
          streamFormat = 'hls';
        } else if (urlLower.endsWith('.ts') || urlLower.includes('/live/') || urlLower.includes('.ts?')) {
          streamFormat = 'ts';
        } else if (urlLower.endsWith('.mp4') || urlLower.endsWith('.mkv') || urlLower.endsWith('.webm')) {
          streamFormat = 'mp4';
        }

        channels.push({
          id: `ch-${channels.length + 1}-${Math.random().toString(36).substring(2, 7)}`,
          number: currentMeta.channelNumber || fallbackNumber,
          name: currentMeta.name,
          category: currentMeta.groupTitle || 'General',
          logo: currentMeta.tvgLogo || '📺',
          isHD,
          is4K,
          currentShow: {
            title: `Live Broadcast: ${currentMeta.name}`,
            startTime: '00:00',
            endTime: '23:59',
            progressPercent: 45,
            genre: currentMeta.groupTitle || 'Live IPTV',
            rating: is4K ? '4K UHD' : isHD ? '1080p HD' : 'SD',
            synopsis: `Live high-definition broadcast feed. Category: ${currentMeta.groupTitle || 'General'}. Direct stream URL: ${streamUrl}`,
          },
          nextShow: {
            title: `Upcoming: ${currentMeta.name} Programming`,
            startTime: 'Next',
          },
          streamUrl,
          backupStreamUrl: streamUrl.endsWith('.m3u8') ? streamUrl.replace('.m3u8', '.ts') : undefined,
          languages: ['Original / Multi'],
          audioPid: 'PID-101 (Stereo/Dolby)',
          currentBitrate: is4K ? '18.5 Mbps' : isHD ? '8.5 Mbps' : '3.5 Mbps',
          tvgId: currentMeta.tvgId,
          tvgName: currentMeta.tvgName,
          groupTitle: currentMeta.groupTitle,
          streamFormat,
        });

        fallbackNumber++;
      }
      currentMeta = null;
    }
  }

  return channels;
}

/**
 * Fetches an M3U playlist from a remote URL via backend proxy or direct fetch
 */
export async function fetchM3uFromUrl(url: string): Promise<Channel[]> {
  // First try via server proxy to bypass CORS
  try {
    const proxyUrl = `/api/iptv/m3u-proxy?url=${encodeURIComponent(url)}`;
    const res = await fetch(proxyUrl);
    if (res.ok) {
      const text = await res.text();
      const channels = parseM3u(text);
      if (channels.length > 0) return channels;
    }
  } catch (err) {
    console.warn('Proxy fetch failed, attempting direct fetch:', err);
  }

  // Direct fetch fallback
  const directRes = await fetch(url);
  if (!directRes.ok) {
    throw new Error(`Playlist server returned HTTP ${directRes.status}: ${directRes.statusText}`);
  }
  const directText = await directRes.text();
  return parseM3u(directText);
}

/**
 * Authenticates with an Xtream Codes server
 */
export async function loginXtreamCodes(serverUrl: string, username: string, password: string) {
  const res = await fetch('/api/iptv/xtream/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ serverUrl, username, password }),
  });

  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to authenticate with Xtream Codes server');
  }
  return data;
}

/**
 * Fetches Live Streams from an Xtream Codes server
 */
export async function fetchXtreamChannels(serverUrl: string, username: string, password: string): Promise<Channel[]> {
  const cleanServer = serverUrl.replace(/\/+$/, '');

  // Fetch categories mapping
  let categoryMap = new Map<string, string>();
  try {
    const catRes = await fetch('/api/iptv/xtream/streams', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ serverUrl, username, password, action: 'get_live_categories' }),
    });
    if (catRes.ok) {
      const catData = await catRes.json();
      if (Array.isArray(catData.data)) {
        catData.data.forEach((c: any) => {
          categoryMap.set(String(c.category_id), c.category_name);
        });
      }
    }
  } catch (err) {
    console.warn('Could not fetch Xtream categories, using default names:', err);
  }

  // Fetch streams
  const res = await fetch('/api/iptv/xtream/streams', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ serverUrl, username, password, action: 'get_live_streams' }),
  });

  const json = await res.json();
  if (!res.ok || !json.success || !Array.isArray(json.data)) {
    throw new Error(json.error || 'No live streams returned from Xtream Codes server');
  }

  const streams = json.data;
  return streams.map((s: any, idx: number): Channel => {
    const categoryName = categoryMap.get(String(s.category_id)) || 'Live TV';
    const is4K = s.name.toUpperCase().includes('4K') || s.name.toUpperCase().includes('UHD');
    const isHD = is4K || s.name.toUpperCase().includes('HD') || s.name.toUpperCase().includes('FHD');
    
    // Xtream stream URLs: HLS (.m3u8) or MPEG-TS (.ts)
    const streamUrl = `${cleanServer}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${s.stream_id}.m3u8`;
    const backupStreamUrl = `${cleanServer}/live/${encodeURIComponent(username)}/${encodeURIComponent(password)}/${s.stream_id}.ts`;

    return {
      id: `xtream-${s.stream_id || idx}`,
      number: s.num ? parseInt(s.num, 10) : idx + 1,
      name: s.name || `Channel ${idx + 1}`,
      category: categoryName,
      logo: s.stream_icon || '📺',
      isHD,
      is4K,
      currentShow: {
        title: s.name,
        startTime: '00:00',
        endTime: '23:59',
        progressPercent: 50,
        genre: categoryName,
        rating: is4K ? '4K UHD' : isHD ? '1080p HD' : 'SD',
        synopsis: `Live Xtream Codes stream from ${cleanServer}. Stream ID: ${s.stream_id}`,
      },
      streamUrl,
      backupStreamUrl,
      languages: ['Original / Multi'],
      audioPid: 'PID-101',
      currentBitrate: is4K ? '18.0 Mbps' : '8.0 Mbps',
      tvgId: s.epg_channel_id,
      tvgName: s.name,
      groupTitle: categoryName,
      streamFormat: 'hls',
    };
  });
}

/**
 * Curated public legal test channels for instant testing all formats (HLS, TS, MP4)
 */
export const SAMPLE_FREE_CHANNELS: Channel[] = [
  {
    id: 'sample-bloomberg',
    number: 1,
    name: 'Bloomberg TV Live',
    category: 'News',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/53/Bloomberg_News_logo.svg/320px-Bloomberg_News_logo.svg.png',
    isHD: true,
    is4K: false,
    currentShow: {
      title: 'Bloomberg Markets & Global Financial News',
      startTime: 'Live',
      endTime: 'Continuous',
      progressPercent: 60,
      genre: 'Business / Finance',
      rating: '1080p HD',
      synopsis: 'Live worldwide financial, business, and tech news with expert Wall Street analysis.',
    },
    streamUrl: 'https://liveproduseast.global.ssl.fastly.net/btv/desktop/us_live.m3u8',
    languages: ['English'],
    audioPid: 'PID-101',
    currentBitrate: '6.5 Mbps',
    streamFormat: 'hls',
  },
  {
    id: 'sample-nasa',
    number: 2,
    name: 'NASA TV HD',
    category: 'Infotainment',
    logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/NASA_logo.svg/320px-NASA_logo.svg.png',
    isHD: true,
    is4K: true,
    currentShow: {
      title: 'International Space Station Live Earth Views',
      startTime: 'Live',
      endTime: 'Continuous',
      progressPercent: 75,
      genre: 'Science & Space',
      rating: '4K UHD',
      synopsis: 'Live video feed from the International Space Station (ISS) orbiting Earth with astronaut mission audio.',
    },
    streamUrl: 'https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8',
    languages: ['English'],
    audioPid: 'PID-201',
    currentBitrate: '14.2 Mbps',
    streamFormat: 'hls',
  },
  {
    id: 'sample-france24',
    number: 3,
    name: 'France 24 English HD',
    category: 'News',
    logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f4/France_24_logo.svg/320px-France_24_logo.svg.png',
    isHD: true,
    is4K: false,
    currentShow: {
      title: 'World News Headlines Live',
      startTime: 'Live',
      endTime: 'Continuous',
      progressPercent: 40,
      genre: 'World News',
      rating: '1080p HD',
      synopsis: 'International breaking news, political updates, and cultural coverage from France 24 in English.',
    },
    streamUrl: 'https://static.france24.com/live/F24_EN_LO_HLS/live_tv.m3u8',
    languages: ['English'],
    audioPid: 'PID-301',
    currentBitrate: '7.8 Mbps',
    streamFormat: 'hls',
  },
  {
    id: 'sample-aljazeera',
    number: 4,
    name: 'Al Jazeera English HD',
    category: 'News',
    logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/Al_Jazeera_English_logo.svg/320px-Al_Jazeera_English_logo.svg.png',
    isHD: true,
    is4K: false,
    currentShow: {
      title: 'Al Jazeera News Hour',
      startTime: 'Live',
      endTime: 'Continuous',
      progressPercent: 55,
      genre: 'Global News',
      rating: '1080p HD',
      synopsis: 'Global in-depth investigative reports and live coverage from correspondents worldwide.',
    },
    streamUrl: 'https://live-hls-web-aje.getaj.net/AJE/01.m3u8',
    languages: ['English'],
    audioPid: 'PID-401',
    currentBitrate: '6.2 Mbps',
    streamFormat: 'hls',
  },
  {
    id: 'sample-redbull',
    number: 5,
    name: 'Red Bull TV 4K Action',
    category: 'Sports',
    logo: 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f5/Red_Bull_TV_logo.svg/320px-Red_Bull_TV_logo.svg.png',
    isHD: true,
    is4K: true,
    currentShow: {
      title: 'Extreme Sports World Tour & Cliff Diving',
      startTime: 'Live',
      endTime: 'Continuous',
      progressPercent: 82,
      genre: 'Extreme Sports',
      rating: '4K 60fps',
      synopsis: 'High-adrenaline action sports, Formula 1 behind-the-scenes, downhill mountain biking, and surf championships.',
    },
    streamUrl: 'https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8',
    languages: ['English'],
    audioPid: 'PID-501',
    currentBitrate: '18.0 Mbps',
    streamFormat: 'hls',
  },
  {
    id: 'sample-mp4-test',
    number: 6,
    name: '4K Broadcast Demo (MP4 Test)',
    category: 'Entertainment',
    logo: '🎬',
    isHD: true,
    is4K: true,
    currentShow: {
      title: 'Tears of Steel 4K UHD Master',
      startTime: 'Continuous',
      endTime: 'Loop',
      progressPercent: 30,
      genre: 'Sci-Fi Film',
      rating: '4K HDR',
      synopsis: 'VFX open-source 4K reference benchmark testing high-bitrate video decoding.',
    },
    streamUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
    languages: ['English'],
    audioPid: 'PID-601',
    currentBitrate: '20.0 Mbps',
    streamFormat: 'mp4',
  },
];
