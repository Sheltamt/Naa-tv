export type OttPlatform = 
  | 'Netflix'
  | 'Prime Video'
  | 'Disney+ Hotstar'
  | 'SonyLIV'
  | 'Zee5'
  | 'Apple TV+'
  | 'Tata Play Binge';

export type ChannelCategory = string;

export interface Channel {
  id: string;
  number: number;
  name: string;
  category: string;
  logo: string;
  isHD: boolean;
  is4K: boolean;
  currentShow: {
    title: string;
    startTime: string;
    endTime: string;
    progressPercent: number;
    genre: string;
    rating: string;
    synopsis: string;
  };
  nextShow?: {
    title: string;
    startTime: string;
  };
  streamUrl: string;
  backupStreamUrl?: string;
  languages: string[];
  audioPid: string;
  currentBitrate: string;
  tvgId?: string;
  tvgName?: string;
  groupTitle?: string;
  streamFormat?: 'hls' | 'ts' | 'mp4' | 'auto';
}

export interface XtreamConfig {
  serverUrl: string;
  username: string;
  password: string;
  userInfo?: {
    username?: string;
    status?: string;
    exp_date?: string;
    is_trial?: string;
    active_cons?: string;
    max_connections?: string;
    message?: string;
  };
  serverInfo?: {
    url?: string;
    port?: string;
    server_protocol?: string;
    timezone?: string;
  };
}

export interface M3uPlaylistInfo {
  id: string;
  name: string;
  url?: string;
  channelCount: number;
  importedAt: string;
  sourceType: 'file' | 'url' | 'paste' | 'xtream';
}

export interface EpgProgram {
  id: string;
  channelId: string;
  title: string;
  startTime: string;
  endTime: string;
  durationMinutes: number;
  genre: string;
  rating: string;
  synopsis: string;
  isLive: boolean;
  isCatchup: boolean;
  cast?: string[];
}

export interface OttTitle {
  id: string;
  title: string;
  platform: OttPlatform;
  type: 'Movie' | 'Series' | 'Live Match' | 'Documentary';
  posterUrl: string;
  backdropUrl: string;
  genre: string;
  rating: string; // e.g. "IMDb 8.5"
  releaseYear: number;
  duration: string;
  description: string;
  isIncludedInBinge: boolean;
  deepLinkUrl: string;
  progressPercent?: number;
  badges: string[];
  cast: string[];
}

export interface StreamTelemetry {
  latencyMs: number;
  bufferHealthPercent: string;
  bitrateMbps: string;
  resolution: string;
  codec: string;
  audioFormat: string;
  cdnEdge: string;
  packetLoss: string;
  jitterMs: number;
  framerate: string;
  drmStatus: string;
}

export interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  color: string;
  role: 'Family' | 'Sports Enthusiast' | 'Kids' | 'Cinephile';
  preferences: string[];
  isKids?: boolean;
}

export interface VoiceSearchResponse {
  spokenFeedback: string;
  intent: 'tune_channel' | 'filter_ott' | 'search_titles' | 'general_recommendation';
  targetChannelKeyword: string | null;
  targetOttPlatform: string | null;
  genre: string | null;
  suggestedQuery: string;
}

export interface AiRecommendation {
  title: string;
  platform: string;
  type: string;
  genre: string;
  rating: string;
  badge: string;
  reason: string;
  channelNumber: number | null;
}
