import { Channel, EpgProgram } from '../types';

// Demo channels removed as requested. Real channels are loaded via M3U playlist or Xtream Codes.
export const CHANNELS_DATA: Channel[] = [];

export const SAMPLE_EPG_PROGRAMS: Record<string, EpgProgram[]> = {};

export const EPG_TIMELINE_SLOTS: string[] = [
  '19:00', '19:30', '20:00', '20:30', '21:00', '21:30', '22:00', '22:30', '23:00'
];

export const EPG_SCHEDULE: Record<string, EpgProgram[]> = {};
