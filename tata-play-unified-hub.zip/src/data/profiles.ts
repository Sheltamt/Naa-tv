import { UserProfile } from '../types';

export const USER_PROFILES: UserProfile[] = [
  {
    id: 'prof-family',
    name: 'Family',
    avatar: '👨‍👩‍👧‍👦',
    color: '#e1005a', // Tata Play magenta
    role: 'Family',
    preferences: ['Live Cricket', 'Hindi GEC', 'Blockbuster Movies', 'Panchayat'],
  },
  {
    id: 'prof-sports',
    name: 'Rahul (Sports)',
    avatar: '⚡',
    color: '#00d2ff', // Cyan
    role: 'Sports Enthusiast',
    preferences: ['Live Cricket 4K', 'Premier League', 'F1 Racing', 'Formula 1 Netflix'],
  },
  {
    id: 'prof-cinephile',
    name: 'Pooja (Binge)',
    avatar: '🍿',
    color: '#a855f7', // Purple
    role: 'Cinephile',
    preferences: ['Netflix Originals', 'Prime Video Thrillers', 'True Crime', 'SonyLIV'],
  },
  {
    id: 'prof-kids',
    name: 'Aarav (Kids)',
    avatar: '🚀',
    color: '#f59e0b', // Amber
    role: 'Kids',
    preferences: ['Cartoon Network', 'Spider-Man', 'Ben 10', 'Animation 4K'],
  },
];

export const OTT_BRAND_CONFIG: Record<string, { name: string; badgeBg: string; textCol: string; accentBorder: string; icon: string }> = {
  'Netflix': {
    name: 'Netflix',
    badgeBg: 'bg-[#E50914]',
    textCol: 'text-white',
    accentBorder: 'border-[#E50914]',
    icon: 'N',
  },
  'Prime Video': {
    name: 'Prime Video',
    badgeBg: 'bg-[#00A8E1]',
    textCol: 'text-white',
    accentBorder: 'border-[#00A8E1]',
    icon: 'prime',
  },
  'Disney+ Hotstar': {
    name: 'Disney+ Hotstar',
    badgeBg: 'bg-[#113CCF]',
    textCol: 'text-white',
    accentBorder: 'border-[#113CCF]',
    icon: 'D+',
  },
  'SonyLIV': {
    name: 'SonyLIV',
    badgeBg: 'bg-[#2970FF]',
    textCol: 'text-white',
    accentBorder: 'border-[#2970FF]',
    icon: 'LIV',
  },
  'Zee5': {
    name: 'ZEE5',
    badgeBg: 'bg-[#7E12C8]',
    textCol: 'text-white',
    accentBorder: 'border-[#7E12C8]',
    icon: 'Z5',
  },
  'Apple TV+': {
    name: 'Apple TV+',
    badgeBg: 'bg-zinc-800',
    textCol: 'text-white',
    accentBorder: 'border-zinc-500',
    icon: 'tv+',
  },
  'Tata Play Binge': {
    name: 'Tata Play Live TV',
    badgeBg: 'bg-[#E1005A]',
    textCol: 'text-white',
    accentBorder: 'border-[#E1005A]',
    icon: '▶',
  },
};
