import React, { useState } from 'react';
import { 
  Play, 
  Plus, 
  Check, 
  Sparkles, 
  ExternalLink, 
  Info, 
  Tv, 
  Zap, 
  Trophy, 
  Clock, 
  Star,
  ChevronRight,
  Flame,
  Film
} from 'lucide-react';
import { Channel, OttTitle, OttPlatform, UserProfile, AiRecommendation } from '../types';
import { OTT_CATALOG } from '../data/ottCatalog';
import { CHANNELS_DATA } from '../data/channels';
import { OTT_BRAND_CONFIG } from '../data/profiles';

interface UnifiedDashboardProps {
  onTuneChannel: (channel: Channel) => void;
  onSelectOttTitle: (title: OttTitle) => void;
  activeProfile: UserProfile;
  aiRecommendations: AiRecommendation[];
  isLoadingAi: boolean;
  onRefreshAi: () => void;
}

export const UnifiedDashboard: React.FC<UnifiedDashboardProps> = ({
  onTuneChannel,
  onSelectOttTitle,
  activeProfile,
  aiRecommendations,
  isLoadingAi,
  onRefreshAi,
}) => {
  const [selectedPlatformFilter, setSelectedPlatformFilter] = useState<string>('All');
  const [watchlist, setWatchlist] = useState<string[]>(['netflix-stranger-things', 'prime-mirzapur-3']);

  const toggleWatchlist = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (watchlist.includes(id)) {
      setWatchlist(watchlist.filter(i => i !== id));
    } else {
      setWatchlist([...watchlist, id]);
    }
  };

  // Filter OTT catalog by platform
  const filteredOtt = selectedPlatformFilter === 'All'
    ? OTT_CATALOG
    : OTT_CATALOG.filter(item => item.platform === selectedPlatformFilter);

  // Continue watching items
  const continueWatchingItems = OTT_CATALOG.filter(item => item.progressPercent !== undefined);

  // Live Sports channels
  const sportsChannels = CHANNELS_DATA.filter(c => c.category === 'Sports');

  // Featured Hero Item (Dynamic)
  const featuredItem = OTT_CATALOG[0]; // The Railway Men (Netflix) or Live Cricket

  return (
    <div className="space-y-10 pb-16">
      
      {/* 1. Cinematic Hero Showcase Banner */}
      <section 
        id="dashboard-hero-banner"
        className="relative w-full rounded-3xl overflow-hidden border border-white/10 bg-[#0d121f] shadow-2xl min-h-[420px] flex items-end p-6 sm:p-10"
      >
        {/* Backdrop image with dark gradient wash */}
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-40 scale-105 transition-transform duration-1000"
          style={{ backgroundImage: `url(${featuredItem.backdropUrl})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#080b11] via-[#080b11]/80 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#080b11] via-[#080b11]/60 to-transparent" />

        {/* Content Container */}
        <div className="relative z-10 max-w-3xl space-y-4">
          
          {/* Badges */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded-md bg-[#E50914] text-white text-xs font-bold tracking-wide">
              {featuredItem.platform}
            </span>
            <span className="px-2.5 py-1 rounded-md bg-white/10 backdrop-blur-md text-cyan-300 border border-cyan-400/30 text-xs font-semibold">
              Tata Play Binge Pass Included
            </span>
            <span className="px-2.5 py-1 rounded-md bg-white/10 backdrop-blur-md text-amber-300 border border-amber-400/30 text-xs font-semibold flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
              {featuredItem.rating}
            </span>
            <span className="px-2 py-0.5 rounded bg-black/40 text-slate-300 text-xs font-mono">
              4K Dolby Vision
            </span>
          </div>

          {/* Title */}
          <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tight leading-none drop-shadow-md">
            {featuredItem.title}
          </h1>

          {/* Synopsis */}
          <p className="text-sm sm:text-base text-slate-300 line-clamp-3 leading-relaxed max-w-2xl font-normal">
            {featuredItem.description}
          </p>

          {/* Cast */}
          <p className="text-xs text-slate-400 font-medium">
            Starring: <span className="text-slate-200">{featuredItem.cast.join(', ')}</span>
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              id="hero-watch-btn"
              onClick={() => onSelectOttTitle(featuredItem)}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#e1005a] to-[#ff2a7a] hover:from-[#ff1a70] hover:to-[#ff458f] text-white font-bold text-sm shadow-xl shadow-[#e1005a]/30 flex items-center gap-2 hover:scale-[1.02] active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Watch on {featuredItem.platform}</span>
            </button>

            <button
              id="hero-tune-live-cricket-btn"
              onClick={() => {
                const cricketCh = CHANNELS_DATA.find(c => c.id === 'star-sports-1-hd');
                if (cricketCh) onTuneChannel(cricketCh);
              }}
              className="px-5 py-3 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/15 text-white font-semibold text-sm flex items-center gap-2 backdrop-blur-md transition-all hover:scale-[1.02] active:scale-95"
            >
              <Tv className="w-4 h-4 text-cyan-400" />
              <span>Tune Live Cricket (401 Star Sports)</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            </button>

            <button
              id="hero-watchlist-btn"
              onClick={(e) => toggleWatchlist(featuredItem.id, e)}
              className="p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-all"
              title="Add to Unified Watchlist"
            >
              {watchlist.includes(featuredItem.id) ? (
                <Check className="w-4 h-4 text-emerald-400" />
              ) : (
                <Plus className="w-4 h-4" />
              )}
            </button>
          </div>

        </div>
      </section>

      {/* 2. Unified Continue Watching Across Apps (Live TV + Netflix + Prime) */}
      <section id="continue-watching-section" className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Clock className="w-5 h-5 text-cyan-400" />
            <h2 className="text-xl font-bold text-white tracking-wide">Continue Watching Across Apps</h2>
            <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20 font-mono">
              Auto-Synced
            </span>
          </div>
          <span className="text-xs text-slate-400 font-medium">Synced with your Android TV profile</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {continueWatchingItems.map(item => {
            const brand = OTT_BRAND_CONFIG[item.platform] || { badgeBg: 'bg-zinc-700', textCol: 'text-white', icon: '▶' };
            return (
              <div
                key={item.id}
                id={`continue-watch-${item.id}`}
                onClick={() => onSelectOttTitle(item)}
                className="group relative rounded-2xl overflow-hidden bg-[#111726] border border-white/10 hover:border-cyan-400/60 transition-all duration-200 cursor-pointer shadow-lg hover:shadow-cyan-500/10 hover:-translate-y-1"
              >
                {/* Poster / Backdrop */}
                <div className="relative h-44 w-full overflow-hidden bg-slate-900">
                  <img
                    src={item.backdropUrl}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111726] via-transparent to-black/40" />

                  {/* Platform Brand Badge */}
                  <div className="absolute top-3 left-3">
                    <span className={`px-2 py-0.5 rounded-md ${brand.badgeBg} ${brand.textCol} text-[11px] font-bold shadow-md`}>
                      {item.platform}
                    </span>
                  </div>

                  {/* Play Overlay Button */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                    <div className="w-12 h-12 rounded-full bg-[#e1005a] flex items-center justify-center text-white shadow-xl scale-90 group-hover:scale-100 transition-transform">
                      <Play className="w-5 h-5 fill-white ml-0.5" />
                    </div>
                  </div>

                  {/* Progress Bar */}
                  <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-white/20">
                    <div 
                      className="h-full bg-gradient-to-r from-[#e1005a] to-cyan-400"
                      style={{ width: `${item.progressPercent || 50}%` }}
                    />
                  </div>
                </div>

                {/* Details */}
                <div className="p-3.5">
                  <div className="flex items-center justify-between gap-2 mb-1">
                    <h3 className="font-bold text-sm text-white truncate group-hover:text-cyan-300 transition-colors">
                      {item.title}
                    </h3>
                    <span className="text-[11px] font-mono text-cyan-400 font-semibold shrink-0">
                      {item.progressPercent}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span>{item.genre}</span>
                    <span>{item.duration}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 3. AI Personalized Recommendations for Current Profile */}
      <section id="gemini-ai-recommendations-section" className="space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-400 via-rose-500 to-amber-400 p-[2px] flex items-center justify-center shadow-lg">
              <div className="w-full h-full bg-slate-900 rounded-[6px] flex items-center justify-center">
                <Sparkles className="w-3.5 h-3.5 text-cyan-300 animate-spin-slow" />
              </div>
            </div>
            <div>
              <h2 className="text-xl font-bold text-white tracking-wide flex items-center gap-2">
                Personalized For {activeProfile.name}
                <span className="text-xs font-normal text-slate-400">
                  (Based on {activeProfile.role} profile)
                </span>
              </h2>
            </div>
          </div>

          <button
            id="refresh-ai-recommendations-btn"
            onClick={onRefreshAi}
            disabled={isLoadingAi}
            className="px-3 py-1.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-300 hover:text-white flex items-center gap-1.5 transition-colors disabled:opacity-50"
          >
            <Sparkles className={`w-3.5 h-3.5 text-amber-400 ${isLoadingAi ? 'animate-spin' : ''}`} />
            <span>{isLoadingAi ? 'Curating AI Picks...' : 'Refresh AI Picks'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {aiRecommendations.map((rec, i) => (
            <div
              key={i}
              id={`ai-rec-card-${i}`}
              onClick={() => {
                if (rec.channelNumber) {
                  const ch = CHANNELS_DATA.find(c => c.number === rec.channelNumber);
                  if (ch) onTuneChannel(ch);
                } else {
                  const matchedOtt = OTT_CATALOG.find(o => o.title.toLowerCase().includes(rec.title.toLowerCase()));
                  if (matchedOtt) onSelectOttTitle(matchedOtt);
                }
              }}
              className="p-4 rounded-2xl bg-gradient-to-b from-[#141b2d] to-[#0e1422] border border-cyan-500/20 hover:border-cyan-400/60 p-4 transition-all duration-200 cursor-pointer shadow-lg hover:shadow-cyan-500/10 group flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#e1005a]/20 text-[#ff4b8d] border border-[#e1005a]/30">
                    {rec.platform}
                  </span>
                  <span className="text-[10px] font-mono text-emerald-400 font-semibold">
                    {rec.badge}
                  </span>
                </div>

                <h3 className="font-bold text-white text-base group-hover:text-cyan-300 transition-colors line-clamp-1 mb-1">
                  {rec.title}
                </h3>
                <p className="text-xs text-slate-400 font-medium mb-2">
                  {rec.genre} • {rec.type}
                </p>

                <p className="text-xs text-slate-300/90 leading-relaxed italic line-clamp-2 bg-white/5 p-2 rounded-xl border border-white/5">
                  "{rec.reason}"
                </p>
              </div>

              <div className="mt-4 pt-3 border-t border-white/10 flex items-center justify-between">
                <span className="text-xs text-amber-300 font-semibold">{rec.rating}</span>
                <span className="text-xs text-cyan-400 font-bold flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  {rec.channelNumber ? `Tune Ch ${rec.channelNumber}` : 'Stream Now'}
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 4. Live Cricket & Sports Central (Low-latency IPTV Showcase) */}
      <section id="sports-central-section" className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Trophy className="w-5 h-5 text-amber-400" />
            <h2 className="text-xl font-bold text-white tracking-wide">Live Sports & Match Center</h2>
            <span className="px-2 py-0.5 rounded-full bg-red-600/20 text-red-400 border border-red-500/30 text-xs font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping" />
              LIVE 4K
            </span>
          </div>
          <span className="text-xs text-emerald-400 font-mono hidden sm:inline-block">
            Tata Play Low Latency Glass-to-Glass &lt; 145ms
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sportsChannels.map(ch => (
            <div
              key={ch.id}
              id={`sports-card-${ch.id}`}
              onClick={() => onTuneChannel(ch)}
              className="group p-4 rounded-2xl bg-gradient-to-br from-[#121929] to-[#0c1220] border border-white/10 hover:border-emerald-400/60 transition-all cursor-pointer shadow-xl hover:-translate-y-1"
            >
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <span className="w-8 h-8 rounded-lg bg-black/40 flex items-center justify-center text-lg">
                    {ch.logo}
                  </span>
                  <div>
                    <h3 className="font-bold text-sm text-white">{ch.name}</h3>
                    <span className="text-[10px] font-mono text-cyan-400">CH {ch.number}</span>
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold font-mono">
                  142ms IPTV
                </span>
              </div>

              <div className="bg-black/40 p-3 rounded-xl border border-white/5 mb-3">
                <p className="text-xs font-bold text-slate-100 line-clamp-1">{ch.currentShow.title}</p>
                <p className="text-[11px] text-slate-400 mt-0.5 line-clamp-2">{ch.currentShow.synopsis}</p>
              </div>

              <div className="flex items-center justify-between text-xs pt-1">
                <span className="text-slate-400 font-mono">{ch.currentShow.startTime} - {ch.currentShow.endTime}</span>
                <span className="font-bold text-cyan-400 flex items-center gap-1 group-hover:text-emerald-300 transition-colors">
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Tune Stream</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. Unified OTT Hub (Netflix, Prime Video, Disney+ Hotstar, SonyLIV, Zee5) */}
      <section id="unified-ott-hub-section" className="space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <Film className="w-5 h-5 text-[#e1005a]" />
              <h2 className="text-xl font-bold text-white tracking-wide">All-in-One Binge OTT Apps</h2>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              One subscription, universal search and instant playback across external streaming services
            </p>
          </div>

          {/* OTT Platform Filter Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 max-w-full">
            {['All', 'Netflix', 'Prime Video', 'Disney+ Hotstar', 'SonyLIV', 'Zee5', 'Apple TV+'].map(plat => {
              const isActive = selectedPlatformFilter === plat;
              return (
                <button
                  key={plat}
                  id={`filter-plat-${plat.toLowerCase().replace(/\s+/g, '-')}`}
                  onClick={() => setSelectedPlatformFilter(plat)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                    isActive 
                      ? 'bg-gradient-to-r from-[#e1005a] to-[#ff2a7a] text-white shadow-md' 
                      : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
                  }`}
                >
                  {plat}
                </button>
              );
            })}
          </div>
        </div>

        {/* OTT Titles Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {filteredOtt.map(title => {
            const brand = OTT_BRAND_CONFIG[title.platform] || { badgeBg: 'bg-zinc-700', textCol: 'text-white' };
            const isSaved = watchlist.includes(title.id);
            return (
              <div
                key={title.id}
                id={`ott-card-${title.id}`}
                onClick={() => onSelectOttTitle(title)}
                className="group relative rounded-2xl overflow-hidden bg-[#111624] border border-white/10 hover:border-[#e1005a] transition-all duration-200 cursor-pointer shadow-lg hover:-translate-y-1.5 flex flex-col"
              >
                {/* Poster */}
                <div className="relative aspect-[2/3] w-full overflow-hidden bg-slate-900">
                  <img
                    src={title.posterUrl}
                    alt={title.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111624] via-transparent to-transparent opacity-80" />

                  {/* Brand Tag Top Left */}
                  <div className="absolute top-2 left-2">
                    <span className={`px-2 py-0.5 rounded ${brand.badgeBg} ${brand.textCol} text-[10px] font-bold shadow`}>
                      {title.platform}
                    </span>
                  </div>

                  {/* Watchlist toggle */}
                  <button
                    onClick={(e) => toggleWatchlist(title.id, e)}
                    className="absolute top-2 right-2 p-1.5 rounded-lg bg-black/60 hover:bg-black/90 text-white transition-colors backdrop-blur-sm"
                    title={isSaved ? 'In Watchlist' : 'Add to Watchlist'}
                  >
                    {isSaved ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Plus className="w-3.5 h-3.5" />}
                  </button>

                  {/* Hover play icon */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40">
                    <div className="w-10 h-10 rounded-full bg-[#e1005a] flex items-center justify-center text-white shadow-xl scale-90 group-hover:scale-100 transition-transform">
                      <Play className="w-4 h-4 fill-white ml-0.5" />
                    </div>
                  </div>
                </div>

                {/* Info */}
                <div className="p-3 flex-1 flex flex-col justify-between">
                  <div>
                    <h3 className="font-bold text-xs sm:text-sm text-white line-clamp-1 group-hover:text-cyan-300 transition-colors">
                      {title.title}
                    </h3>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      {title.genre}
                    </p>
                  </div>
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-white/5 text-[10px]">
                    <span className="text-amber-300 font-semibold">{title.rating}</span>
                    <span className="text-cyan-400 font-medium">{title.releaseYear}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* 6. Popular Live Tata Play IPTV Channels Quick Grid */}
      <section id="popular-channels-grid-section" className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Tv className="w-5 h-5 text-cyan-400" />
            <h2 className="text-xl font-bold text-white tracking-wide">Browse Live Tata Play Channels</h2>
          </div>
          <span className="text-xs text-slate-400">Click any channel to tune instantly</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
          {CHANNELS_DATA.map(ch => (
            <button
              key={ch.id}
              id={`browse-channel-${ch.id}`}
              onClick={() => onTuneChannel(ch)}
              className="p-3.5 rounded-2xl bg-[#111726]/80 hover:bg-[#151e33] border border-white/10 hover:border-cyan-400/60 transition-all text-left group flex flex-col justify-between h-32 shadow-md hover:-translate-y-1"
            >
              <div className="flex items-start justify-between w-full">
                <span className="text-2xl">{ch.logo}</span>
                <span className="font-mono text-xs font-bold text-cyan-400 px-1.5 py-0.5 rounded bg-black/40">
                  {ch.number}
                </span>
              </div>

              <div>
                <h3 className="font-bold text-sm text-white truncate group-hover:text-cyan-300 transition-colors">
                  {ch.name}
                </h3>
                <p className="text-[11px] text-slate-400 truncate mt-0.5">
                  {ch.currentShow.title}
                </p>
              </div>
            </button>
          ))}
        </div>
      </section>

    </div>
  );
};
