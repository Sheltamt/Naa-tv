import React, { useState } from 'react';
import { 
  X, 
  Power, 
  Mic, 
  Home, 
  ArrowLeft, 
  Volume2, 
  VolumeX, 
  ChevronUp, 
  ChevronDown, 
  ChevronLeft, 
  ChevronRight, 
  Radio, 
  Tv, 
  SlidersHorizontal,
  Info,
  Calendar,
  Sparkles
} from 'lucide-react';

interface RemoteControlSimulatorProps {
  isOpen: boolean;
  onClose: () => void;
  onRemoveRemote?: () => void;
  onNavigate: (direction: 'up' | 'down' | 'left' | 'right' | 'select' | 'back' | 'home') => void;
  onVoiceSearch: () => void;
  onNumberPress: (num: string) => void;
  onChannelStep: (step: 1 | -1) => void;
  onVolumeStep: (step: 1 | -1) => void;
  onToggleMute: () => void;
  onOpenEpg: () => void;
  onOpenDiagnostics: () => void;
  onQuickApp: (app: 'netflix' | 'prime' | 'binge' | 'live') => void;
}

export const RemoteControlSimulator: React.FC<RemoteControlSimulatorProps> = ({
  isOpen,
  onClose,
  onRemoveRemote,
  onNavigate,
  onVoiceSearch,
  onNumberPress,
  onChannelStep,
  onVolumeStep,
  onToggleMute,
  onOpenEpg,
  onOpenDiagnostics,
  onQuickApp,
}) => {
  const [activeLed, setActiveLed] = useState(false);

  const triggerLed = () => {
    setActiveLed(true);
    setTimeout(() => setActiveLed(false), 200);
  };

  if (!isOpen) return null;

  return (
    <div 
      id="android-tv-remote-container"
      className="fixed right-4 bottom-4 top-20 z-50 w-72 max-h-[85vh] bg-[#121622] rounded-3xl border-2 border-white/20 shadow-2xl p-4 flex flex-col justify-between overflow-y-auto custom-scrollbar animate-in slide-in-from-right duration-200"
    >
      {/* Remote Top: LED & Power & Close */}
      <div className="flex items-center justify-between pb-3 border-b border-white/10">
        <div className="flex items-center gap-2">
          {/* IR Blaster / Bluetooth LED */}
          <div className={`w-3 h-3 rounded-full transition-colors ${activeLed ? 'bg-cyan-400 shadow-md shadow-cyan-400' : 'bg-red-950 border border-red-500/40'}`} />
          <span className="text-[10px] font-bold tracking-widest text-slate-400 uppercase">TATA PLAY VOICE</span>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="remote-btn-power"
            onClick={() => {
              triggerLed();
              onNavigate('home');
            }}
            className="p-1.5 rounded-full bg-red-600/20 text-red-400 hover:bg-red-600/40 border border-red-500/30 transition-colors"
            title="TV Power"
          >
            <Power className="w-4 h-4" />
          </button>
          <button
            id="remote-btn-close"
            onClick={onClose}
            className="p-1.5 rounded-full bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white"
            title="Close Remote"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Voice Assistant Button (Google Assistant / Tata Play) */}
      <div className="py-2 text-center">
        <button
          id="remote-btn-voice"
          onClick={() => {
            triggerLed();
            onVoiceSearch();
          }}
          className="w-full py-2.5 px-4 rounded-2xl bg-gradient-to-r from-blue-600/30 via-rose-600/30 to-amber-600/30 border border-cyan-400/50 hover:border-cyan-400 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-lg group hover:scale-[1.02] active:scale-95 transition-all"
        >
          <div className="w-5 h-5 rounded-full bg-slate-900 flex items-center justify-center">
            <Mic className="w-3.5 h-3.5 text-cyan-300 group-hover:scale-110 transition-transform" />
          </div>
          <span>Google Voice Assistant</span>
        </button>
      </div>

      {/* Directional Pad (D-Pad) with OK/Select center */}
      <div className="flex justify-center py-2">
        <div className="relative w-44 h-44 rounded-full bg-[#181f33] border border-white/10 shadow-inner flex items-center justify-center p-2">
          
          {/* UP Button */}
          <button
            id="remote-dpad-up"
            onClick={() => {
              triggerLed();
              onNavigate('up');
            }}
            className="absolute top-1.5 left-1/2 -translate-x-1/2 w-12 h-10 rounded-t-full hover:bg-white/10 active:bg-cyan-500/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            title="Up"
          >
            <ChevronUp className="w-5 h-5" />
          </button>

          {/* DOWN Button */}
          <button
            id="remote-dpad-down"
            onClick={() => {
              triggerLed();
              onNavigate('down');
            }}
            className="absolute bottom-1.5 left-1/2 -translate-x-1/2 w-12 h-10 rounded-b-full hover:bg-white/10 active:bg-cyan-500/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            title="Down"
          >
            <ChevronDown className="w-5 h-5" />
          </button>

          {/* LEFT Button */}
          <button
            id="remote-dpad-left"
            onClick={() => {
              triggerLed();
              onNavigate('left');
            }}
            className="absolute left-1.5 top-1/2 -translate-y-1/2 w-10 h-12 rounded-l-full hover:bg-white/10 active:bg-cyan-500/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            title="Left"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          {/* RIGHT Button */}
          <button
            id="remote-dpad-right"
            onClick={() => {
              triggerLed();
              onNavigate('right');
            }}
            className="absolute right-1.5 top-1/2 -translate-y-1/2 w-10 h-12 rounded-r-full hover:bg-white/10 active:bg-cyan-500/20 flex items-center justify-center text-slate-300 hover:text-white transition-colors"
            title="Right"
          >
            <ChevronRight className="w-5 h-5" />
          </button>

          {/* CENTER SELECT / OK */}
          <button
            id="remote-dpad-ok"
            onClick={() => {
              triggerLed();
              onNavigate('select');
            }}
            className="w-16 h-16 rounded-full bg-gradient-to-br from-[#e1005a] to-[#99003c] hover:from-[#ff1a70] text-white font-extrabold text-sm shadow-xl active:scale-95 transition-all flex items-center justify-center"
            title="OK / Select"
          >
            OK
          </button>

        </div>
      </div>

      {/* Nav Controls: Back, Home, Guide */}
      <div className="grid grid-cols-3 gap-2 py-2">
        <button
          id="remote-btn-back"
          onClick={() => {
            triggerLed();
            onNavigate('back');
          }}
          className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 active:bg-white/20 text-slate-300 hover:text-white flex flex-col items-center gap-1 transition-colors"
          title="Back (Escape)"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="text-[9px] uppercase font-bold text-slate-400">Back</span>
        </button>

        <button
          id="remote-btn-home"
          onClick={() => {
            triggerLed();
            onNavigate('home');
          }}
          className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 active:bg-white/20 text-slate-300 hover:text-white flex flex-col items-center gap-1 transition-colors"
          title="Home Dashboard"
        >
          <Home className="w-4 h-4 text-cyan-400" />
          <span className="text-[9px] uppercase font-bold text-slate-400">Home</span>
        </button>

        <button
          id="remote-btn-epg"
          onClick={() => {
            triggerLed();
            onOpenEpg();
          }}
          className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 active:bg-white/20 text-slate-300 hover:text-white flex flex-col items-center gap-1 transition-colors"
          title="TV Guide (G)"
        >
          <Calendar className="w-4 h-4 text-amber-400" />
          <span className="text-[9px] uppercase font-bold text-slate-400">Guide</span>
        </button>
      </div>

      {/* Volume & Channel Rockers */}
      <div className="grid grid-cols-2 gap-3 py-2 bg-black/30 p-2.5 rounded-2xl border border-white/5">
        {/* Vol Column */}
        <div className="flex flex-col items-center gap-1 bg-white/5 p-1.5 rounded-xl">
          <button
            id="remote-btn-vol-up"
            onClick={() => {
              triggerLed();
              onVolumeStep(1);
            }}
            className="w-full py-1.5 rounded-lg hover:bg-white/10 active:bg-cyan-500/20 flex items-center justify-center text-xs font-bold text-slate-200"
            title="Volume +"
          >
            +
          </button>
          <span className="text-[10px] font-mono font-bold text-slate-400">VOL</span>
          <button
            id="remote-btn-vol-down"
            onClick={() => {
              triggerLed();
              onVolumeStep(-1);
            }}
            className="w-full py-1.5 rounded-lg hover:bg-white/10 active:bg-cyan-500/20 flex items-center justify-center text-xs font-bold text-slate-200"
            title="Volume -"
          >
            -
          </button>
        </div>

        {/* Ch Column */}
        <div className="flex flex-col items-center gap-1 bg-white/5 p-1.5 rounded-xl">
          <button
            id="remote-btn-ch-up"
            onClick={() => {
              triggerLed();
              onChannelStep(1);
            }}
            className="w-full py-1.5 rounded-lg hover:bg-white/10 active:bg-cyan-500/20 flex items-center justify-center text-xs font-bold text-slate-200"
            title="Channel +"
          >
            ▲
          </button>
          <span className="text-[10px] font-mono font-bold text-cyan-400">CH</span>
          <button
            id="remote-btn-ch-down"
            onClick={() => {
              triggerLed();
              onChannelStep(-1);
            }}
            className="w-full py-1.5 rounded-lg hover:bg-white/10 active:bg-cyan-500/20 flex items-center justify-center text-xs font-bold text-slate-200"
            title="Channel -"
          >
            ▼
          </button>
        </div>
      </div>

      {/* Dedicated Streaming App Shortcut Buttons */}
      <div className="grid grid-cols-2 gap-2 pt-2">
        <button
          id="remote-shortcut-netflix"
          onClick={() => {
            triggerLed();
            onQuickApp('netflix');
          }}
          className="py-2 px-3 rounded-xl bg-[#E50914]/20 hover:bg-[#E50914]/40 border border-[#E50914]/40 text-white font-extrabold text-xs shadow-md transition-all active:scale-95"
        >
          NETFLIX
        </button>

        <button
          id="remote-shortcut-prime"
          onClick={() => {
            triggerLed();
            onQuickApp('prime');
          }}
          className="py-2 px-3 rounded-xl bg-[#00A8E1]/20 hover:bg-[#00A8E1]/40 border border-[#00A8E1]/40 text-[#00A8E1] hover:text-white font-extrabold text-xs shadow-md transition-all active:scale-95"
        >
          prime video
        </button>

        <button
          id="remote-shortcut-binge"
          onClick={() => {
            triggerLed();
            onQuickApp('binge');
          }}
          className="py-2 px-3 rounded-xl bg-[#E1005A]/20 hover:bg-[#E1005A]/40 border border-[#E1005A]/40 text-[#ff3388] font-bold text-xs shadow-md transition-all active:scale-95"
        >
          BINGE OTT
        </button>

        <button
          id="remote-shortcut-live"
          onClick={() => {
            triggerLed();
            onQuickApp('live');
          }}
          className="py-2 px-3 rounded-xl bg-cyan-600/20 hover:bg-cyan-600/40 border border-cyan-400/40 text-cyan-300 font-bold text-xs shadow-md transition-all active:scale-95"
        >
          LIVE TV
        </button>
      </div>

      {/* Number Keypad Toggle (0-9 for channel tuning) */}
      <div className="grid grid-cols-3 gap-1.5 pt-2 border-t border-white/10">
        {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'Info', '0', 'Mute'].map(key => (
          <button
            key={key}
            id={`remote-key-${key.toLowerCase()}`}
            onClick={() => {
              triggerLed();
              if (key === 'Info') onOpenDiagnostics();
              else if (key === 'Mute') onToggleMute();
              else onNumberPress(key);
            }}
            className="py-1.5 rounded-lg bg-white/5 hover:bg-white/10 active:bg-cyan-500/20 text-xs font-mono font-bold text-slate-300 hover:text-white transition-colors"
          >
            {key}
          </button>
        ))}
      </div>

      {/* Remove Remote Option Button */}
      {onRemoveRemote && (
        <div className="pt-2 border-t border-white/5">
          <button
            id="remove-remote-option-btn"
            onClick={onRemoveRemote}
            className="w-full py-1.5 rounded-xl bg-white/5 hover:bg-red-500/20 border border-white/10 hover:border-red-500/30 text-[11px] font-semibold text-slate-400 hover:text-red-300 transition-colors flex items-center justify-center gap-1.5"
            title="Remove or disable virtual remote"
          >
            <X className="w-3.5 h-3.5 text-red-400" />
            <span>Remove Remote</span>
          </button>
        </div>
      )}

    </div>
  );
};
