import React, { useState, useEffect } from 'react';
import { 
  Tv, 
  Mic, 
  SlidersHorizontal, 
  ChevronDown,
  Zap,
  List,
  Activity,
  Plus,
  Radio,
  Eye,
  EyeOff
} from 'lucide-react';
import { Channel, UserProfile } from '../types';
import { USER_PROFILES } from '../data/profiles';

interface NavigationHeaderProps {
  currentChannel: Channel | null;
  channelsCount: number;
  activeProfile: UserProfile;
  onProfileChange: (profile: UserProfile) => void;
  onOpenVoiceSearch: () => void;
  onToggleRemote: () => void;
  isRemoteOpen: boolean;
  isRemoteEnabled?: boolean;
  onToggleRemoteEnabled?: () => void;
  onOpenDiagnostics: () => void;
  currentLatency: number;
  onToggleChannelList?: () => void;
  isChannelListOpen?: boolean;
  onOpenPlaylistModal: () => void;
}

export const NavigationHeader: React.FC<NavigationHeaderProps> = ({
  currentChannel,
  channelsCount,
  activeProfile,
  onProfileChange,
  onOpenVoiceSearch,
  onToggleRemote,
  isRemoteOpen,
  isRemoteEnabled = true,
  onToggleRemoteEnabled,
  onOpenDiagnostics,
  currentLatency,
  onToggleChannelList,
  isChannelListOpen,
  onOpenPlaylistModal,
}) => {
  const [currentTime, setCurrentTime] = useState('');
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [isRemoteMenuOpen, setIsRemoteMenuOpen] = useState(false);

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      setCurrentTime(
        now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })
      );
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  return (
    <header className="sticky top-0 z-40 w-full bg-[#090d16]/95 backdrop-blur-md border-b border-white/10 px-4 lg:px-8 py-3 transition-all">
      <div className="max-w-[1920px] mx-auto flex items-center justify-between gap-4">
        
        {/* Left: Tata Play Brand & IPTV Player Indicator */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2.5">
            {/* Tata Play Signature Logo Box */}
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-[#e1005a] to-[#99003c] shadow-lg shadow-[#e1005a]/25">
              <span className="font-extrabold text-white text-lg tracking-tight">TP</span>
              <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-[#00d2ff] animate-ping opacity-75" />
              <div className="absolute -top-1 -right-1 w-3 h-3 rounded-full bg-[#00d2ff]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-wider text-white">TATA<span className="text-[#e1005a]">PLAY</span></span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#e1005a]/20 text-[#ff3377] border border-[#e1005a]/30">IPTV PLAYER</span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium tracking-wide flex items-center gap-1">
                Low-Latency Stream Engine <span className="text-emerald-400">● M3U & Xtream</span>
              </p>
            </div>
          </div>

          {/* Low Latency Performance Badge */}
          <button 
            id="diagnostics-pill-btn"
            onClick={onOpenDiagnostics}
            className="hidden xl:flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-medium hover:bg-emerald-500/20 transition-colors"
            title="Ultra-low latency diagnostics"
          >
            <Zap className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
            <span>Low Latency: <strong className="text-white font-mono">{currentLatency}ms</strong></span>
            <span className="text-emerald-400/60">• All Formats</span>
          </button>
        </div>

        {/* Center: Currently Tuned Channel Banner Pill */}
        {currentChannel ? (
          <div className="hidden md:flex items-center gap-3 bg-white/5 border border-white/10 px-4 py-2 rounded-2xl backdrop-blur-md">
            <div className="w-8 h-8 rounded-lg bg-black/40 flex items-center justify-center text-lg overflow-hidden shrink-0">
              {currentChannel.logo.startsWith('http') ? (
                <img 
                  src={currentChannel.logo} 
                  alt={currentChannel.name} 
                  className="w-full h-full object-contain p-0.5" 
                  crossOrigin="anonymous"
                  referrerPolicy="no-referrer"
                  onError={(e) => {
                    (e.target as HTMLElement).style.display = 'none';
                  }}
                />
              ) : (
                currentChannel.logo || '📺'
              )}
            </div>
            <div className="text-left">
              <div className="flex items-center gap-2">
                <span className="font-mono text-cyan-400 font-extrabold text-sm">
                  CH {currentChannel.number}
                </span>
                <span className="font-bold text-white text-sm">
                  {currentChannel.name}
                </span>
                {currentChannel.is4K && (
                  <span className="px-1.5 py-0.2 text-[9px] font-extrabold rounded bg-amber-500/20 text-amber-300 border border-amber-400/40 font-mono">
                    4K UHD
                  </span>
                )}
                <span className="px-1.5 py-0.2 text-[9px] rounded bg-white/10 text-slate-300">
                  {currentChannel.category}
                </span>
              </div>
              <p className="text-xs text-slate-300 truncate max-w-sm">
                <span className="text-white/60">Now: </span>
                {currentChannel.currentShow?.title || 'Live Stream'}
              </p>
            </div>
          </div>
        ) : (
          <button
            onClick={onOpenPlaylistModal}
            className="hidden md:flex items-center gap-2 px-4 py-2 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold hover:bg-cyan-500/20 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Load M3U Playlist or Xtream Codes</span>
          </button>
        )}

        {/* Right: Playlist Import, Channels Drawer, Remote Toggle, Voice, Profile */}
        <div className="flex items-center gap-2">
          
          {/* Add M3U / Xtream Playlist Button */}
          <button
            id="header-add-playlist-btn"
            onClick={onOpenPlaylistModal}
            className="px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 bg-gradient-to-r from-[#e1005a] to-[#ff2a7a] text-white shadow-md shadow-[#e1005a]/25 hover:opacity-95 transition-opacity"
            title="Import M3U file, URL or Xtream Codes"
          >
            <Plus className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Playlist</span>
            <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-black/30">
              {channelsCount}
            </span>
          </button>

          {/* Quick Channels List Button */}
          {onToggleChannelList && (
            <button
              id="header-channels-toggle-btn"
              onClick={onToggleChannelList}
              className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                isChannelListOpen
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300 shadow-md shadow-cyan-500/20'
                  : 'bg-white/5 border-white/10 text-slate-300 hover:text-white hover:bg-white/10'
              }`}
              title="Browse IPTV Channel Guide"
            >
              <List className="w-4 h-4 text-cyan-400" />
              <span className="hidden lg:inline">Channels</span>
            </button>
          )}

          {/* Voice Search Button */}
          <button
            id="header-voice-search-btn"
            onClick={onOpenVoiceSearch}
            className="relative group p-2 rounded-xl bg-gradient-to-r from-blue-600/20 via-rose-600/20 to-amber-600/20 border border-white/15 hover:border-cyan-400/60 transition-all flex items-center gap-2 text-white shadow-lg"
            title="Activate Voice Search (Press 'V')"
          >
            <div className="w-6 h-6 rounded-full bg-gradient-to-tr from-cyan-400 via-rose-500 to-amber-400 p-[2px] flex items-center justify-center animate-pulse">
              <div className="w-full h-full bg-slate-900 rounded-full flex items-center justify-center">
                <Mic className="w-3.5 h-3.5 text-cyan-300" />
              </div>
            </div>
            <span className="text-xs font-semibold hidden lg:inline-block pr-1 text-slate-200 group-hover:text-white">
              Voice Zap
            </span>
            <kbd className="hidden xl:inline-block px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-black/40 rounded border border-white/10">V</kbd>
          </button>

          {/* Virtual Remote Control Toggle & Remove Option */}
          <div className="relative">
            <div className="flex items-center rounded-xl bg-white/5 border border-white/10">
              <button
                id="toggle-remote-btn"
                onClick={onToggleRemote}
                disabled={!isRemoteEnabled}
                className={`px-2.5 py-2 rounded-l-xl transition-all flex items-center gap-1.5 ${
                  !isRemoteEnabled
                    ? 'opacity-40 cursor-not-allowed text-slate-500'
                    : isRemoteOpen 
                    ? 'bg-[#00d2ff]/20 text-cyan-300' 
                    : 'text-slate-300 hover:text-white'
                }`}
                title={isRemoteEnabled ? "Toggle Remote (Press 'R')" : "Remote is disabled"}
              >
                <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-medium hidden sm:inline-block">Remote</span>
                <kbd className="hidden xl:inline-block px-1 py-0.2 text-[9px] font-mono text-slate-400 bg-black/40 rounded border border-white/10">R</kbd>
              </button>

              {/* Remote Options Dropdown (Add / Remove Remote) */}
              <button
                id="remote-options-dropdown-btn"
                onClick={() => setIsRemoteMenuOpen(!isRemoteMenuOpen)}
                className="px-1.5 py-2 hover:bg-white/10 rounded-r-xl border-l border-white/10 text-slate-400 hover:text-white transition-colors"
                title="Add or remove remote option"
              >
                <ChevronDown className="w-3 h-3" />
              </button>
            </div>

            {isRemoteMenuOpen && (
              <div className="absolute right-0 mt-2 w-48 bg-[#121724] border border-white/15 rounded-2xl shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150 text-xs">
                <div className="px-2.5 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Remote Control
                </div>
                {onToggleRemoteEnabled && (
                  <button
                    onClick={() => {
                      onToggleRemoteEnabled();
                      setIsRemoteMenuOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-xl flex items-center justify-between hover:bg-white/10 text-slate-200 transition-colors"
                  >
                    <div className="flex items-center gap-2">
                      {isRemoteEnabled ? <EyeOff className="w-3.5 h-3.5 text-red-400" /> : <Eye className="w-3.5 h-3.5 text-emerald-400" />}
                      <span>{isRemoteEnabled ? 'Remove Remote' : 'Add Remote'}</span>
                    </div>
                  </button>
                )}
                {isRemoteEnabled && (
                  <button
                    onClick={() => {
                      onToggleRemote();
                      setIsRemoteMenuOpen(false);
                    }}
                    className="w-full text-left px-2.5 py-2 rounded-xl flex items-center justify-between hover:bg-white/10 text-slate-200 transition-colors"
                  >
                    <span>{isRemoteOpen ? 'Hide Remote' : 'Show Remote'}</span>
                    <span className="text-[10px] font-mono text-cyan-400">R</span>
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Stream Diagnostics Icon Button */}
          <button
            id="header-diagnostics-btn"
            onClick={onOpenDiagnostics}
            className="p-2.5 rounded-xl bg-white/5 border border-white/10 text-slate-300 hover:text-white hover:bg-white/10 transition-colors"
            title="Stream Stats & Diagnostics (Press 'I')"
          >
            <Activity className="w-4 h-4 text-emerald-400" />
          </button>

          {/* Clock */}
          <div className="hidden sm:flex flex-col items-end px-2">
            <span className="font-mono text-sm font-semibold tracking-wider text-slate-100">{currentTime}</span>
            <span className="text-[10px] text-slate-400">Live IPTV</span>
          </div>

          {/* Profile Switcher */}
          <div className="relative">
            <button
              id="profile-dropdown-btn"
              onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
              className="flex items-center gap-2 p-1.5 pr-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 transition-colors"
            >
              <div 
                className="w-7 h-7 rounded-lg flex items-center justify-center text-sm font-bold shadow"
                style={{ backgroundColor: activeProfile.color }}
              >
                {activeProfile.avatar}
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {/* Profile Menu Dropdown */}
            {isProfileMenuOpen && (
              <div className="absolute right-0 mt-2 w-56 bg-[#121724] border border-white/15 rounded-2xl shadow-2xl p-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                <div className="px-3 py-2 border-b border-white/10 mb-1">
                  <p className="text-[11px] font-medium text-slate-400 uppercase tracking-wider">Switch Profile</p>
                  <p className="text-xs font-bold text-white mt-0.5">IPTV Preferences</p>
                </div>
                {USER_PROFILES.map((p) => (
                  <button
                    key={p.id}
                    id={`profile-opt-${p.id}`}
                    onClick={() => {
                      onProfileChange(p);
                      setIsProfileMenuOpen(false);
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-xl text-left transition-colors text-xs ${
                      p.id === activeProfile.id ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'hover:bg-white/5 text-slate-300'
                    }`}
                  >
                    <div 
                      className="w-6 h-6 rounded-md flex items-center justify-center text-xs"
                      style={{ backgroundColor: p.color }}
                    >
                      {p.avatar}
                    </div>
                    <span>{p.name}</span>
                    {p.isKids && (
                      <span className="text-[9px] px-1 py-0.2 rounded bg-amber-400/20 text-amber-300 font-semibold ml-auto">
                        Kids
                      </span>
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

      </div>
    </header>
  );
};
