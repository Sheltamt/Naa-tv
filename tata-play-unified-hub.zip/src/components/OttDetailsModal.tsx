import React, { useState } from 'react';
import { 
  X, 
  Play, 
  ExternalLink, 
  Check, 
  Plus, 
  Star, 
  Sparkles, 
  Share2,
  Tv,
  Film
} from 'lucide-react';
import { OttTitle } from '../types';
import { OTT_BRAND_CONFIG } from '../data/profiles';

interface OttDetailsModalProps {
  title: OttTitle | null;
  onClose: () => void;
  onPlayDirectPreview: (videoUrl: string) => void;
}

export const OttDetailsModal: React.FC<OttDetailsModalProps> = ({
  title,
  onClose,
  onPlayDirectPreview,
}) => {
  const [isInWatchlist, setIsInWatchlist] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);

  if (!title) return null;

  const brand = OTT_BRAND_CONFIG[title.platform] || { 
    badgeBg: 'bg-zinc-700', 
    textCol: 'text-white', 
    accentBorder: 'border-zinc-500' 
  };

  const handleDeepLinkOpen = () => {
    // Open external streaming service URL
    window.open(title.deepLinkUrl, '_blank', 'noopener,noreferrer');
  };

  return (
    <div 
      id="ott-details-modal"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200"
    >
      <div className="bg-[#0f1422] border border-white/15 rounded-3xl w-full max-w-3xl overflow-hidden shadow-2xl relative max-h-[90vh] flex flex-col">
        
        {/* Backdrop Banner Header */}
        <div className="relative h-64 sm:h-72 w-full overflow-hidden bg-slate-900 shrink-0">
          <img
            src={title.backdropUrl}
            alt={title.title}
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0f1422] via-[#0f1422]/60 to-transparent" />
          
          {/* Close button */}
          <button
            id="close-ott-details-btn"
            onClick={onClose}
            className="absolute top-4 right-4 p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-white transition-colors backdrop-blur-md z-10"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Platform Tag Badge */}
          <div className="absolute top-4 left-4 z-10 flex items-center gap-2">
            <span className={`px-3 py-1 rounded-xl ${brand.badgeBg} ${brand.textCol} text-xs font-black shadow-lg uppercase tracking-wider`}>
              {title.platform}
            </span>
            {title.isIncludedInBinge && (
              <span className="px-2.5 py-1 rounded-xl bg-[#e1005a]/30 text-rose-300 border border-[#e1005a]/50 text-xs font-bold backdrop-blur-md">
                Included with Tata Play Binge
              </span>
            )}
          </div>

          {/* Title & Quick Info over backdrop */}
          <div className="absolute bottom-4 left-6 right-6 z-10 space-y-2">
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
              <span className="text-amber-300 flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-amber-300" />
                {title.rating}
              </span>
              <span className="text-slate-400">•</span>
              <span className="text-slate-200">{title.releaseYear}</span>
              <span className="text-slate-400">•</span>
              <span className="text-slate-200">{title.duration}</span>
              <span className="text-slate-400">•</span>
              <span className="px-2 py-0.5 rounded bg-black/40 text-cyan-300 font-mono text-[10px] border border-white/10">
                {title.badges[0] || '4K UHD'}
              </span>
            </div>

            <h1 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-none drop-shadow">
              {title.title}
            </h1>
          </div>
        </div>

        {/* Modal Body Info */}
        <div className="p-6 space-y-5 overflow-y-auto custom-scrollbar flex-1">
          
          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              id="deep-link-launch-btn"
              onClick={handleDeepLinkOpen}
              className="px-6 py-3 rounded-2xl bg-gradient-to-r from-[#e1005a] to-[#ff2a7a] hover:from-[#ff1a70] text-white font-bold text-sm flex items-center gap-2 shadow-xl shadow-[#e1005a]/30 active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Watch on {title.platform}</span>
              <ExternalLink className="w-3.5 h-3.5 ml-0.5" />
            </button>

            <button
              id="ott-watchlist-btn"
              onClick={() => setIsInWatchlist(!isInWatchlist)}
              className={`px-4 py-3 rounded-2xl border text-sm font-semibold flex items-center gap-2 transition-all ${
                isInWatchlist 
                  ? 'bg-emerald-600/20 border-emerald-400 text-emerald-300' 
                  : 'bg-white/5 hover:bg-white/10 border-white/15 text-slate-200'
              }`}
            >
              {isInWatchlist ? <Check className="w-4 h-4 text-emerald-400" /> : <Plus className="w-4 h-4" />}
              <span>{isInWatchlist ? 'In Watchlist' : 'Add to Watchlist'}</span>
            </button>

            <button
              id="ott-share-btn"
              onClick={() => {
                navigator.clipboard?.writeText(window.location.href);
                setCopiedLink(true);
                setTimeout(() => setCopiedLink(false), 2000);
              }}
              className="p-3 rounded-2xl bg-white/5 hover:bg-white/10 border border-white/10 text-slate-300 hover:text-white transition-colors"
              title="Share Title"
            >
              <Share2 className="w-4 h-4" />
            </button>
            {copiedLink && (
              <span className="text-xs text-emerald-400 font-semibold animate-in fade-in">
                Link copied to clipboard!
              </span>
            )}
          </div>

          {/* Synopsis */}
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Synopsis</h3>
            <p className="text-sm text-slate-200 leading-relaxed">
              {title.description}
            </p>
          </div>

          {/* Cast & Crew */}
          <div>
            <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1.5">Cast</h3>
            <div className="flex flex-wrap gap-2">
              {title.cast.map(actor => (
                <span
                  key={actor}
                  className="px-3 py-1 rounded-xl bg-white/5 border border-white/10 text-xs font-medium text-slate-200"
                >
                  {actor}
                </span>
              ))}
            </div>
          </div>

          {/* Audio & Video Badges */}
          <div className="pt-2 border-t border-white/10 flex flex-wrap items-center gap-2">
            <span className="text-xs text-slate-400 font-medium">Available Features:</span>
            {title.badges.map(b => (
              <span 
                key={b}
                className="px-2.5 py-1 rounded-lg bg-black/40 border border-cyan-500/20 text-cyan-300 text-[11px] font-mono"
              >
                {b}
              </span>
            ))}
          </div>

        </div>

      </div>
    </div>
  );
};
