import React, { useState, useEffect, useRef, useMemo } from 'react';
import Hls from 'hls.js';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Minimize, 
  Zap, 
  Radio, 
  ChevronLeft, 
  ChevronRight, 
  List, 
  SlidersHorizontal, 
  Check,
  Tv,
  Plus,
  RefreshCw,
  AlertTriangle,
  ShieldAlert,
  Sparkles,
  Wifi,
  ExternalLink,
  Film
} from 'lucide-react';
import { Channel } from '../types';

interface LivePlayerProps {
  currentChannel: Channel | null;
  channels: Channel[];
  onSelectChannel: (channel: Channel) => void;
  isPiP?: boolean;
  onTogglePiP?: () => void;
  onOpenDiagnostics: () => void;
  currentLatency: number;
  isChannelDrawerOpen?: boolean;
  onToggleChannelDrawer?: () => void;
  onOpenImportModal: () => void;
  isRemoteOpen?: boolean;
  isRemoteEnabled?: boolean;
  onToggleRemote?: () => void;
  onRemoveRemote?: () => void;
  onAddRemote?: () => void;
}

export const LivePlayer: React.FC<LivePlayerProps> = ({
  currentChannel,
  channels,
  onSelectChannel,
  isPiP = false,
  onTogglePiP,
  onOpenDiagnostics,
  currentLatency,
  isChannelDrawerOpen,
  onToggleChannelDrawer,
  onOpenImportModal,
  isRemoteOpen,
  isRemoteEnabled = true,
  onToggleRemote,
  onRemoveRemote,
  onAddRemote,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const playerContainerRef = useRef<HTMLDivElement>(null);
  const hlsRef = useRef<Hls | null>(null);

  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(false);
  const [volume, setVolume] = useState(0.85);
  const [showOverlay, setShowOverlay] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [localShowChannelList, setLocalShowChannelList] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [channelSearchTerm, setChannelSearchTerm] = useState('');
  const [zapBannerVisible, setZapBannerVisible] = useState(true);
  const [buffering, setBuffering] = useState(false);
  const [numberBuffer, setNumberBuffer] = useState('');
  const [streamError, setStreamError] = useState<string | null>(null);
  const [useProxy, setUseProxy] = useState(false);

  // Available audio tracks and qualities from Hls.js
  const [audioTracks, setAudioTracks] = useState<Array<{ id: number; name: string; lang: string }>>([]);
  const [selectedAudioTrack, setSelectedAudioTrack] = useState<number>(-1);
  const [qualityLevels, setQualityLevels] = useState<Array<{ id: number; height: number; bitrate: number }>>([]);
  const [selectedQuality, setSelectedQuality] = useState<number>(-1); // -1 = Auto
  const [showAudioQualityMenu, setShowAudioQualityMenu] = useState(false);

  const channelDrawerActive = isChannelDrawerOpen !== undefined ? isChannelDrawerOpen : localShowChannelList;
  const toggleDrawer = onToggleChannelDrawer || (() => setLocalShowChannelList(prev => !prev));

  // Determine categories dynamically from loaded channels
  const categories = useMemo(() => {
    const set = new Set<string>(['All']);
    channels.forEach(ch => {
      if (ch.category) set.add(ch.category);
    });
    return Array.from(set);
  }, [channels]);

  const filteredChannels = useMemo(() => {
    return channels.filter(ch => {
      const matchesCat = selectedCategory === 'All' || ch.category === selectedCategory;
      const matchesSearch = !channelSearchTerm || 
        ch.name.toLowerCase().includes(channelSearchTerm.toLowerCase()) || 
        ch.number.toString().includes(channelSearchTerm) ||
        ch.currentShow?.title?.toLowerCase().includes(channelSearchTerm.toLowerCase());
      return matchesCat && matchesSearch;
    });
  }, [channels, selectedCategory, channelSearchTerm]);

  // Clean up Hls instance
  const destroyHls = () => {
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }
  };

  // Reset error when switching channels
  useEffect(() => {
    setStreamError(null);
    setUseProxy(false);
    setZapBannerVisible(true);
    setBuffering(true);

    const bannerTimer = setTimeout(() => {
      setZapBannerVisible(false);
    }, 4500);

    return () => clearTimeout(bannerTimer);
  }, [currentChannel?.id]);

  // Main video stream loader supporting all formats (HLS .m3u8, MPEG-TS .ts, MP4, WebM, etc.)
  useEffect(() => {
    if (!currentChannel) {
      destroyHls();
      return;
    }

    const video = videoRef.current;
    if (!video) return;

    destroyHls();
    setBuffering(true);

    let streamUrl = currentChannel.streamUrl;
    if (useProxy) {
      streamUrl = `/api/iptv/stream-proxy?url=${encodeURIComponent(currentChannel.streamUrl)}`;
    }

    const isHls = streamUrl.includes('.m3u8') || currentChannel.streamFormat === 'hls';

    // Format 1: HLS Stream (.m3u8) using hls.js
    if (isHls && Hls.isSupported()) {
      const hls = new Hls({
        enableWorker: true,
        lowLatencyMode: true,
        backBufferLength: 60,
        maxBufferLength: 30,
        maxMaxBufferLength: 60,
      });
      hlsRef.current = hls;

      hls.loadSource(streamUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, (_event, data) => {
        setBuffering(false);
        setStreamError(null);
        
        // Extract quality levels
        if (data.levels && data.levels.length > 0) {
          setQualityLevels(data.levels.map((lvl, index) => ({
            id: index,
            height: lvl.height,
            bitrate: lvl.bitrate,
          })));
        }

        // Extract audio tracks
        if (hls.audioTracks && hls.audioTracks.length > 0) {
          setAudioTracks(hls.audioTracks.map((trk) => ({
            id: trk.id,
            name: trk.name || `Audio ${trk.id + 1}`,
            lang: trk.lang || 'und',
          })));
          setSelectedAudioTrack(hls.audioTrack);
        }

        video.play().catch(() => {
          // Autoplay with audio may require initial mute on some browsers
          video.muted = true;
          setIsMuted(true);
          video.play().catch(() => {});
        });
      });

      hls.on(Hls.Events.AUDIO_TRACK_SWITCHED, (_event, data) => {
        setSelectedAudioTrack(data.id);
      });

      hls.on(Hls.Events.LEVEL_SWITCHED, (_event, data) => {
        setSelectedQuality(data.level);
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        console.warn('HLS stream error event:', data);
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              setStreamError('Network / CORS error loading stream. Remote provider may restrict direct browser streaming.');
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              destroyHls();
              setStreamError('Fatal playback error. The stream may be offline or in an unsupported codec.');
              break;
          }
        }
      });
    } 
    // Format 2: Native Safari / iOS HLS
    else if (isHls && video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = streamUrl;
      video.play().catch(() => {
        video.muted = true;
        setIsMuted(true);
        video.play().catch(() => {});
      });
    } 
    // Format 3: MPEG-TS, MP4, WebM, or Direct Video URL
    else {
      video.src = streamUrl;
      video.load();
      video.play().catch(() => {
        video.muted = true;
        setIsMuted(true);
        video.play().catch(() => {});
      });
    }

    return () => {
      destroyHls();
    };
  }, [currentChannel?.id, currentChannel?.streamUrl, useProxy]);

  // Video event listeners for buffering & errors
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const onWaiting = () => setBuffering(true);
    const onPlaying = () => {
      setBuffering(false);
      setIsPlaying(true);
      setStreamError(null);
    };
    const onPause = () => setIsPlaying(false);
    const onError = () => {
      setBuffering(false);
      if (!streamError) {
        setStreamError('Playback failed. Remote stream may be offline or blocked by browser CORS.');
      }
    };

    video.addEventListener('waiting', onWaiting);
    video.addEventListener('playing', onPlaying);
    video.addEventListener('pause', onPause);
    video.addEventListener('error', onError);

    return () => {
      video.removeEventListener('waiting', onWaiting);
      video.removeEventListener('playing', onPlaying);
      video.removeEventListener('pause', onPause);
      video.removeEventListener('error', onError);
    };
  }, [streamError]);

  // Handle number buffer input for direct channel tuning
  useEffect(() => {
    if (!numberBuffer) return;
    const timeout = setTimeout(() => {
      const chNum = parseInt(numberBuffer, 10);
      const matched = channels.find(c => c.number === chNum);
      if (matched) {
        onSelectChannel(matched);
      }
      setNumberBuffer('');
    }, 1100);

    return () => clearTimeout(timeout);
  }, [numberBuffer, channels, onSelectChannel]);

  // Handle keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }
      if (/^[0-9]$/.test(e.key)) {
        setNumberBuffer(prev => (prev.length < 3 ? prev + e.key : e.key));
      } else if (e.key === ' ' || e.code === 'Space') {
        e.preventDefault();
        handleTogglePlay();
      } else if (e.key === 'm' || e.key === 'M') {
        handleToggleMute();
      } else if (e.key === 'f' || e.key === 'F') {
        toggleFullscreen();
      } else if (e.key === 'c' || e.key === 'C') {
        toggleDrawer();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, isMuted, toggleDrawer]);

  const handleTogglePlay = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
        setIsPlaying(false);
      } else {
        videoRef.current.play();
        setIsPlaying(true);
      }
    }
  };

  const handleToggleMute = () => {
    if (videoRef.current) {
      const nextMute = !isMuted;
      videoRef.current.muted = nextMute;
      setIsMuted(nextMute);
      if (!nextMute && volume === 0) {
        setVolume(0.85);
        videoRef.current.volume = 0.85;
      }
    }
  };

  const handleVolumeChange = (newVol: number) => {
    setVolume(newVol);
    if (videoRef.current) {
      videoRef.current.volume = newVol;
      if (newVol === 0) {
        videoRef.current.muted = true;
        setIsMuted(true);
      } else if (isMuted) {
        videoRef.current.muted = false;
        setIsMuted(false);
      }
    }
  };

  const toggleFullscreen = () => {
    if (!playerContainerRef.current) return;
    if (!document.fullscreenElement) {
      playerContainerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(() => {});
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false)).catch(() => {});
    }
  };

  const handleSelectAudioTrack = (trackId: number) => {
    if (hlsRef.current) {
      hlsRef.current.audioTrack = trackId;
      setSelectedAudioTrack(trackId);
    }
  };

  const handleSelectQuality = (lvlIndex: number) => {
    if (hlsRef.current) {
      hlsRef.current.currentLevel = lvlIndex;
      setSelectedQuality(lvlIndex);
    }
  };

  // Channel Step
  const handleStep = (direction: 1 | -1) => {
    if (channels.length === 0) return;
    const currentIdx = channels.findIndex(c => c.id === currentChannel?.id);
    const nextIdx = (currentIdx + direction + channels.length) % channels.length;
    onSelectChannel(channels[nextIdx]);
  };

  // If no channels are loaded at all, show pristine Empty State prompting M3U/Xtream load
  if (!currentChannel || channels.length === 0) {
    return (
      <div 
        id="empty-player-placeholder"
        className="w-full aspect-video max-h-[78vh] rounded-3xl bg-[#0a0e18] border-2 border-dashed border-white/20 flex flex-col items-center justify-center p-6 sm:p-10 text-center shadow-2xl relative overflow-hidden"
      >
        <div className="absolute -top-32 -right-32 w-96 h-96 rounded-full bg-[#e1005a]/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full bg-cyan-500/10 blur-3xl pointer-events-none" />

        <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-3xl bg-gradient-to-br from-[#e1005a] to-rose-700 flex items-center justify-center text-white shadow-xl shadow-[#e1005a]/30 mb-5">
          <Tv className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
        </div>

        <h2 className="text-xl sm:text-2xl font-black text-white">
          No Channels Loaded
        </h2>
        <p className="text-xs sm:text-sm text-slate-400 max-w-lg mt-2 leading-relaxed">
          Import your IPTV playlist (<span className="text-cyan-400 font-mono">.m3u</span> / <span className="text-cyan-400 font-mono">.m3u8</span> file or URL) or connect with your <span className="text-[#e1005a] font-bold">Xtream Codes</span> credentials. All formats (HLS, TS, MP4) are supported with low-latency hardware acceleration.
        </p>

        <div className="flex flex-wrap items-center justify-center gap-3 mt-6">
          <button
            id="empty-state-import-btn"
            onClick={onOpenImportModal}
            className="px-5 py-3 rounded-2xl bg-gradient-to-r from-[#e1005a] to-[#ff2a7a] text-white font-bold text-sm shadow-lg shadow-[#e1005a]/30 hover:opacity-95 transition-opacity flex items-center gap-2"
          >
            <Plus className="w-4 h-4" />
            <span>Add M3U / Xtream Codes</span>
          </button>
        </div>
      </div>
    );
  }

  // Detect format label
  const formatBadge = currentChannel.streamUrl.includes('.m3u8')
    ? 'HLS • M3U8'
    : currentChannel.streamUrl.includes('.ts')
    ? 'MPEG-TS'
    : currentChannel.streamUrl.includes('.mp4')
    ? 'MP4'
    : 'LIVE';

  return (
    <div
      ref={playerContainerRef}
      id="live-iptv-player-screen"
      className="relative w-full aspect-video max-h-[78vh] bg-black rounded-3xl overflow-hidden shadow-2xl border border-white/10 group select-none"
      onMouseMove={() => setShowOverlay(true)}
      onMouseLeave={() => setShowOverlay(false)}
    >
      {/* Video Element */}
      <video
        ref={videoRef}
        id="iptv-video-stream"
        playsInline
        autoPlay
        className="w-full h-full object-contain bg-black"
        onClick={handleTogglePlay}
      />

      {/* Buffering Indicator */}
      {buffering && !streamError && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-[2px] z-30 pointer-events-none">
          <div className="flex flex-col items-center gap-2">
            <div className="w-12 h-12 rounded-full border-4 border-cyan-400/20 border-t-cyan-400 animate-spin" />
            <span className="text-xs font-mono font-bold text-cyan-300 tracking-wider">
              TUNING {currentChannel.name.toUpperCase()}...
            </span>
          </div>
        </div>
      )}

      {/* Stream Error Alert Card */}
      {streamError && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/85 backdrop-blur-md z-35 p-6 text-center">
          <div className="max-w-md bg-[#131929] border border-white/15 p-6 rounded-3xl shadow-2xl space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-white text-base">Stream Playback Notice</h3>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                {streamError}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-2 pt-2">
              {!useProxy && (
                <button
                  onClick={() => setUseProxy(true)}
                  className="flex-1 px-4 py-2.5 rounded-xl bg-cyan-500 text-black font-bold text-xs hover:bg-cyan-400 transition-colors flex items-center justify-center gap-1.5"
                >
                  <Wifi className="w-3.5 h-3.5" />
                  <span>Try Stream Proxy</span>
                </button>
              )}
              <button
                onClick={() => {
                  setStreamError(null);
                  if (videoRef.current) {
                    videoRef.current.load();
                    videoRef.current.play().catch(() => {});
                  }
                }}
                className="flex-1 px-4 py-2.5 rounded-xl bg-white/10 text-white font-bold text-xs hover:bg-white/20 transition-colors flex items-center justify-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Feed</span>
              </button>
              <button
                onClick={() => handleStep(1)}
                className="px-3 py-2.5 rounded-xl bg-white/5 text-slate-300 text-xs hover:text-white hover:bg-white/10"
              >
                Zap Next &rarr;
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Direct Channel Number Input OSD Overlay (e.g. typing '401') */}
      {numberBuffer && (
        <div className="absolute top-6 right-6 z-40 bg-black/85 border-2 border-cyan-400 px-5 py-3 rounded-2xl backdrop-blur-md animate-in zoom-in-95 duration-100 flex items-center gap-3 shadow-2xl">
          <Tv className="w-6 h-6 text-cyan-400 animate-pulse" />
          <div>
            <div className="text-[10px] text-cyan-300 font-bold uppercase tracking-widest">Tuning Channel</div>
            <div className="font-mono text-3xl font-black text-white tracking-widest">{numberBuffer}</div>
          </div>
        </div>
      )}

      {/* Android TV Top Stream Quality & Format Watermark */}
      <div className="absolute top-4 left-4 z-20 flex items-center gap-2 pointer-events-none">
        <span className="px-2.5 py-1 rounded-xl bg-black/60 backdrop-blur-md border border-white/15 text-[11px] font-mono text-cyan-300 font-bold flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span>{formatBadge}</span>
        </span>
        {currentChannel.is4K && (
          <span className="px-2 py-1 rounded-xl bg-amber-500/20 backdrop-blur-md border border-amber-400/40 text-[10px] font-mono font-bold text-amber-300">
            4K UHD
          </span>
        )}
        {useProxy && (
          <span className="px-2 py-1 rounded-xl bg-purple-500/20 backdrop-blur-md border border-purple-400/40 text-[10px] font-mono font-bold text-purple-300">
            CORS Proxy Active
          </span>
        )}
      </div>

      {/* On-Screen Program Zap Banner (OSD) */}
      {(zapBannerVisible || showOverlay) && !isPiP && (
        <div className="absolute top-4 inset-x-4 z-20 transition-all duration-300 pointer-events-none">
          <div className="max-w-4xl mx-auto bg-[#0a0f1d]/90 backdrop-blur-xl border border-white/20 rounded-2xl p-3.5 sm:p-4 shadow-2xl pointer-events-auto">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-center gap-3">
                {/* Channel Logo */}
                <div className="w-12 h-12 rounded-xl bg-white/10 border border-white/20 flex items-center justify-center shrink-0 overflow-hidden text-2xl">
                  {currentChannel.logo.startsWith('http') ? (
                    <img 
                      src={currentChannel.logo} 
                      alt={currentChannel.name} 
                      className="w-full h-full object-contain p-1"
                      crossOrigin="anonymous"
                      referrerPolicy="no-referrer"
                      onError={(e) => {
                        (e.target as HTMLElement).style.display = 'none';
                      }}
                    />
                  ) : (
                    currentChannel.logo || '📺'
                  )}
                </div>

                {/* Channel Info */}
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-cyan-400 font-extrabold text-sm">
                      {currentChannel.number}
                    </span>
                    <h1 className="font-extrabold text-white text-base tracking-tight">
                      {currentChannel.name}
                    </h1>
                    <span className="text-[10px] px-2 py-0.5 rounded bg-white/10 text-slate-300 font-medium">
                      {currentChannel.category}
                    </span>
                  </div>

                  <p className="text-xs font-semibold text-slate-200 mt-0.5 line-clamp-1">
                    {currentChannel.currentShow?.title}
                  </p>
                </div>
              </div>

              {/* Broadcast Stats */}
              <div className="hidden sm:flex flex-col items-end shrink-0">
                <div className="flex items-center gap-1.5 text-[11px] font-mono text-emerald-400">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>{currentLatency}ms Anycast</span>
                </div>
                <span className="text-[10px] font-mono text-slate-400 mt-0.5">
                  {currentChannel.currentBitrate || '18.5 Mbps'}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Bottom Floating Control Bar */}
      <div 
        className={`absolute bottom-0 inset-x-0 p-4 sm:p-6 bg-gradient-to-t from-black/95 via-black/70 to-transparent z-30 transition-opacity duration-300 flex flex-col gap-3 ${
          showOverlay ? 'opacity-100' : 'opacity-0 pointer-events-none'
        }`}
      >
        <div className="flex items-center justify-between gap-3">
          
          {/* Left Controls: Play/Pause, Channel Step, Volume */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              id="player-toggle-play-btn"
              onClick={handleTogglePlay}
              className="p-3 rounded-2xl bg-[#e1005a] hover:bg-[#ff1a70] text-white transition-colors shadow-lg shadow-[#e1005a]/30"
              title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
            >
              {isPlaying ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current" />}
            </button>

            {/* Zap Prev / Next Channels */}
            <div className="flex items-center bg-white/10 rounded-2xl border border-white/10 p-1">
              <button
                id="player-prev-channel-btn"
                onClick={() => handleStep(-1)}
                className="p-2 hover:bg-white/10 rounded-xl text-slate-300 hover:text-white transition-colors"
                title="Previous Channel (▲ / Left)"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <div className="h-4 w-px bg-white/15" />
              <button
                id="player-next-channel-btn"
                onClick={() => handleStep(1)}
                className="p-2 hover:bg-white/10 rounded-xl text-slate-300 hover:text-white transition-colors"
                title="Next Channel (▼ / Right)"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Volume Control */}
            <div className="flex items-center gap-2 bg-white/10 px-3 py-2 rounded-2xl border border-white/10">
              <button
                id="player-mute-btn"
                onClick={handleToggleMute}
                className="text-slate-300 hover:text-white transition-colors"
                title="Toggle Mute (M)"
              >
                {isMuted || volume === 0 ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
              </button>
              <input
                id="player-volume-slider"
                type="range"
                min="0"
                max="1"
                step="0.05"
                value={isMuted ? 0 : volume}
                onChange={(e) => handleVolumeChange(parseFloat(e.target.value))}
                className="w-16 sm:w-20 accent-cyan-400 cursor-pointer h-1 bg-white/20 rounded-lg"
              />
            </div>
          </div>

          {/* Right Controls: Audio/Format Menu, Channel Guide Drawer, Remote Option, Diagnostics, Fullscreen */}
          <div className="flex items-center gap-2">
            
            {/* Audio & Quality Menu */}
            <div className="relative">
              <button
                id="player-audio-quality-btn"
                onClick={() => setShowAudioQualityMenu(!showAudioQualityMenu)}
                className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                  showAudioQualityMenu
                    ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                    : 'bg-white/10 border-white/10 text-slate-300 hover:text-white'
                }`}
                title="Select Audio Track & Quality"
              >
                <Film className="w-3.5 h-3.5" />
                <span className="hidden md:inline">Format / Audio</span>
              </button>

              {showAudioQualityMenu && (
                <div className="absolute bottom-full right-0 mb-2 w-64 bg-[#111728] border border-white/20 rounded-2xl p-3 shadow-2xl z-50 text-xs space-y-3">
                  <div>
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                      Stream Format & Proxy
                    </span>
                    <button
                      onClick={() => setUseProxy(!useProxy)}
                      className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center justify-between transition-colors ${
                        useProxy ? 'bg-purple-600/30 text-purple-300 border border-purple-500/40' : 'bg-white/5 text-slate-300 hover:bg-white/10'
                      }`}
                    >
                      <span>CORS Bypass Proxy</span>
                      <span className="text-[10px] font-mono">{useProxy ? 'ON' : 'OFF'}</span>
                    </button>
                  </div>

                  {qualityLevels.length > 0 && (
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        Video Quality ({qualityLevels.length} Levels)
                      </span>
                      <div className="space-y-1 max-h-32 overflow-y-auto custom-scrollbar">
                        <button
                          onClick={() => handleSelectQuality(-1)}
                          className={`w-full text-left px-2 py-1 rounded flex items-center justify-between ${
                            selectedQuality === -1 ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-300 hover:bg-white/5'
                          }`}
                        >
                          <span>Auto (Adaptive)</span>
                          {selectedQuality === -1 && <Check className="w-3 h-3 text-cyan-400" />}
                        </button>
                        {qualityLevels.map((lvl) => (
                          <button
                            key={lvl.id}
                            onClick={() => handleSelectQuality(lvl.id)}
                            className={`w-full text-left px-2 py-1 rounded flex items-center justify-between ${
                              selectedQuality === lvl.id ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-300 hover:bg-white/5'
                            }`}
                          >
                            <span>{lvl.height}p ({Math.round(lvl.bitrate / 1000)}k)</span>
                            {selectedQuality === lvl.id && <Check className="w-3 h-3 text-cyan-400" />}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {audioTracks.length > 0 && (
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1">
                        Audio Track
                      </span>
                      <div className="space-y-1 max-h-28 overflow-y-auto custom-scrollbar">
                        {audioTracks.map((trk) => (
                          <button
                            key={trk.id}
                            onClick={() => handleSelectAudioTrack(trk.id)}
                            className={`w-full text-left px-2 py-1 rounded flex items-center justify-between ${
                              selectedAudioTrack === trk.id ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-300 hover:bg-white/5'
                            }`}
                          >
                            <span>{trk.name} ({trk.lang})</span>
                            {selectedAudioTrack === trk.id && <Check className="w-3 h-3 text-cyan-400" />}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Quick Channel Surf Drawer button */}
            <button
              id="toggle-channel-list-btn"
              onClick={toggleDrawer}
              className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                channelDrawerActive 
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300' 
                  : 'bg-white/10 border-white/10 text-slate-300 hover:text-white'
              }`}
              title="Channels Drawer (C)"
            >
              <List className="w-4 h-4 text-cyan-400" />
              <span className="hidden sm:inline">Channels ({channels.length})</span>
            </button>

            {/* Add & Remove Remote Option Button */}
            {onToggleRemote && (
              <button
                id="player-remote-toggle-btn"
                onClick={onToggleRemote}
                className={`px-3 py-2 rounded-xl text-xs font-semibold flex items-center gap-1.5 border transition-all ${
                  isRemoteOpen 
                    ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300' 
                    : 'bg-white/10 border-white/10 text-slate-300 hover:text-white'
                }`}
                title="Add / Remove Remote (R)"
              >
                <SlidersHorizontal className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">
                  {isRemoteOpen ? 'Close Remote' : 'Remote'}
                </span>
              </button>
            )}

            {/* Stream Diagnostics */}
            <button
              id="player-diagnostics-btn"
              onClick={onOpenDiagnostics}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white border border-white/10"
              title="Stream Diagnostics (I)"
            >
              <Zap className="w-4 h-4 text-emerald-400" />
            </button>

            {/* Fullscreen Button */}
            <button
              id="player-fullscreen-btn"
              onClick={toggleFullscreen}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white border border-white/10"
              title="Fullscreen (F)"
            >
              {isFullscreen ? <Minimize className="w-4 h-4" /> : <Maximize className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Quick Channel Surf Drawer (slides out when 'Channels' clicked) */}
      {channelDrawerActive && !isPiP && (
        <div className="absolute top-0 right-0 bottom-0 w-88 max-w-full bg-[#0c101c]/95 border-l border-white/15 p-4 z-40 backdrop-blur-xl flex flex-col shadow-2xl animate-in slide-in-from-right duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-3">
            <div className="flex items-center gap-2">
              <Tv className="w-4 h-4 text-cyan-400" />
              <h3 className="font-bold text-white text-sm">IPTV Channel Guide</h3>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-white/10 text-cyan-300">
                {filteredChannels.length}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <button
                onClick={onOpenImportModal}
                className="text-[11px] text-cyan-300 hover:text-white px-2 py-1 rounded bg-cyan-500/20 hover:bg-cyan-500/30 transition-colors flex items-center gap-1 font-semibold"
                title="Add M3U or Xtream playlist"
              >
                <Plus className="w-3 h-3" />
                <span>Add</span>
              </button>
              <button
                onClick={toggleDrawer}
                className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-white/5 hover:bg-white/10 transition-colors"
              >
                Close
              </button>
            </div>
          </div>

          {/* Quick Search */}
          <div className="mb-3">
            <input
              type="text"
              placeholder="Search channel or number (e.g. 1)..."
              value={channelSearchTerm}
              onChange={(e) => setChannelSearchTerm(e.target.value)}
              className="w-full bg-black/40 border border-white/15 rounded-xl px-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-sans"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-2 mb-2 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-medium whitespace-nowrap transition-colors ${
                  selectedCategory === cat
                    ? 'bg-[#e1005a] text-white font-bold'
                    : 'bg-white/5 text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
            {filteredChannels.map(ch => {
              const isSelected = ch.id === currentChannel.id;
              return (
                <button
                  key={ch.id}
                  id={`channel-card-${ch.id}`}
                  onClick={() => {
                    onSelectChannel(ch);
                    if (onToggleChannelDrawer) onToggleChannelDrawer();
                    else setLocalShowChannelList(false);
                  }}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-left transition-all ${
                    isSelected 
                      ? 'bg-cyan-500/20 border border-cyan-400 text-white shadow-lg' 
                      : 'bg-white/5 border border-white/5 hover:bg-white/10 text-slate-300'
                  }`}
                >
                  <div className="w-9 h-9 rounded-lg bg-black/50 border border-white/10 flex items-center justify-center text-lg overflow-hidden shrink-0">
                    {ch.logo.startsWith('http') ? (
                      <img 
                        src={ch.logo} 
                        alt={ch.name} 
                        className="w-full h-full object-contain p-0.5"
                        crossOrigin="anonymous"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          (e.target as HTMLElement).style.display = 'none';
                        }}
                      />
                    ) : (
                      ch.logo || '📺'
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="font-mono text-cyan-400 font-bold text-xs">{ch.number}</span>
                      <p className="text-xs font-bold text-white truncate">{ch.name}</p>
                      {ch.is4K && (
                        <span className="text-[9px] px-1 py-0.2 rounded bg-amber-500/20 text-amber-300 font-mono">4K</span>
                      )}
                    </div>
                    <p className="text-[11px] text-slate-400 truncate mt-0.5">
                      {ch.currentShow?.title || ch.category}
                    </p>
                  </div>
                  {isSelected && <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0" />}
                </button>
              );
            })}
            {filteredChannels.length === 0 && (
              <div className="text-center py-8 space-y-2">
                <p className="text-xs text-slate-500">No channels matched</p>
                <button
                  onClick={onOpenImportModal}
                  className="px-3 py-1 rounded-lg bg-cyan-500/20 text-cyan-300 text-xs font-semibold"
                >
                  + Add Channels
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
