import React, { useState, useEffect } from 'react';
import { 
  X, 
  Activity, 
  Zap, 
  Wifi, 
  Server, 
  ShieldCheck, 
  Radio, 
  RefreshCw,
  Cpu,
  Monitor
} from 'lucide-react';
import { StreamTelemetry } from '../types';

interface StreamDiagnosticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  telemetry: StreamTelemetry;
  onRefreshTelemetry: () => void;
}

export const StreamDiagnosticsModal: React.FC<StreamDiagnosticsModalProps> = ({
  isOpen,
  onClose,
  telemetry,
  onRefreshTelemetry,
}) => {
  const [latencyHistory, setLatencyHistory] = useState<number[]>([140, 138, 142, 135, 139, 137, 141, 138]);

  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      onRefreshTelemetry();
      setLatencyHistory(prev => {
        const nextVal = Math.round(telemetry.latencyMs + (Math.random() * 4 - 2));
        return [...prev.slice(1), nextVal];
      });
    }, 2000);
    return () => clearInterval(interval);
  }, [isOpen, telemetry.latencyMs, onRefreshTelemetry]);

  if (!isOpen) return null;

  return (
    <div 
      id="stream-diagnostics-modal"
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200"
    >
      <div className="bg-[#0e1320] border-2 border-emerald-500/40 rounded-3xl w-full max-w-2xl shadow-2xl p-6 sm:p-8 space-y-6 relative overflow-hidden">
        
        {/* Glow ambient accent */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
              <Zap className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-white flex items-center gap-2">
                Ultra Low-Latency IPTV Diagnostics
                <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 font-mono font-bold">
                  HEVC 4K
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                Tata Play Edge Anycast Network • Glass-to-Glass Live Feed Performance
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="refresh-telemetry-btn"
              onClick={onRefreshTelemetry}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
              title="Refresh Stats"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              id="close-diagnostics-btn"
              onClick={onClose}
              className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white transition-colors"
              title="Close"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Live Latency Sparkline & Primary Meters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          
          {/* Latency */}
          <div className="p-4 rounded-2xl bg-black/40 border border-emerald-500/30">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>Glass-to-Glass Latency</span>
              <Activity className="w-3.5 h-3.5 text-emerald-400" />
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-black font-mono text-emerald-400">
                {telemetry.latencyMs}
              </span>
              <span className="text-xs font-mono text-slate-400">ms</span>
            </div>
            <span className="text-[10px] text-emerald-400/80 font-medium">
              ⚡ Ultra Low Delay (&lt;150ms)
            </span>
          </div>

          {/* Buffer Health */}
          <div className="p-4 rounded-2xl bg-black/40 border border-white/10">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>Buffer Health</span>
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-black font-mono text-cyan-400">
                {telemetry.bufferHealthPercent}
              </span>
              <span className="text-xs font-mono text-slate-400">%</span>
            </div>
            <span className="text-[10px] text-cyan-400/80 font-medium">
              Zero stutter stream stability
            </span>
          </div>

          {/* Direct Bitrate */}
          <div className="p-4 rounded-2xl bg-black/40 border border-white/10">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span>Video Bitrate</span>
              <Wifi className="w-3.5 h-3.5 text-amber-400" />
            </div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-black font-mono text-amber-300">
                {telemetry.bitrateMbps}
              </span>
              <span className="text-xs font-mono text-slate-400">Mbps</span>
            </div>
            <span className="text-[10px] text-slate-400 font-medium">
              Adaptive HEVC CBR Stream
            </span>
          </div>

        </div>

        {/* Real-time Latency Chart Visualization */}
        <div className="p-4 rounded-2xl bg-black/50 border border-white/10 space-y-2">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Latency Jitter Timeline (Past 15 seconds)</span>
            <span className="font-mono text-emerald-400">Average: ~139ms</span>
          </div>
          <div className="h-16 flex items-end justify-between gap-2 px-2 pt-2">
            {latencyHistory.map((val, idx) => {
              const heightPercent = Math.min(100, Math.max(30, ((val - 120) / 40) * 100));
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                  <div 
                    className="w-full bg-gradient-to-t from-emerald-600 to-cyan-400 rounded-t-md transition-all duration-300"
                    style={{ height: `${heightPercent}%` }}
                  />
                  <span className="text-[9px] font-mono text-slate-500">{val}</span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Detailed Stream Pipeline Metadata */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
          
          <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Monitor className="w-3.5 h-3.5 text-cyan-400" /> Resolution & Framerate
            </span>
            <span className="font-mono font-bold text-white">{telemetry.resolution}</span>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-amber-400" /> Video Codec
            </span>
            <span className="font-mono font-bold text-white">{telemetry.codec}</span>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Radio className="w-3.5 h-3.5 text-rose-400" /> Audio Master
            </span>
            <span className="font-mono font-bold text-white">{telemetry.audioFormat}</span>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5 text-emerald-400" /> CDN Edge Pop
            </span>
            <span className="font-mono font-bold text-white">{telemetry.cdnEdge}</span>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <Wifi className="w-3.5 h-3.5 text-blue-400" /> Packet Loss
            </span>
            <span className="font-mono font-bold text-emerald-400">{telemetry.packetLoss}</span>
          </div>

          <div className="p-3 rounded-xl bg-white/5 border border-white/5 flex items-center justify-between">
            <span className="text-slate-400 flex items-center gap-1.5">
              <ShieldCheck className="w-3.5 h-3.5 text-purple-400" /> DRM Security
            </span>
            <span className="font-mono font-bold text-white">{telemetry.drmStatus}</span>
          </div>

        </div>

      </div>
    </div>
  );
};
