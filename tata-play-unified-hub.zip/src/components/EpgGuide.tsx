import React, { useState } from 'react';
import { 
  Play, 
  Clock, 
  Calendar, 
  Bookmark, 
  Check, 
  ChevronRight, 
  Tv, 
  Filter,
  Sparkles,
  Info
} from 'lucide-react';
import { Channel, ChannelCategory, EpgProgram } from '../types';
import { CHANNELS_DATA, EPG_SCHEDULE, EPG_TIMELINE_SLOTS } from '../data/channels';

interface EpgGuideProps {
  onTuneChannel: (channel: Channel) => void;
  currentChannel: Channel;
}

export const EpgGuide: React.FC<EpgGuideProps> = ({
  onTuneChannel,
  currentChannel,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<ChannelCategory>('All');
  const [selectedProgram, setSelectedProgram] = useState<EpgProgram | null>(null);
  const [recordedList, setRecordedList] = useState<string[]>([]);

  const categories: ChannelCategory[] = [
    'All',
    'Entertainment',
    'Sports',
    'Movies',
    'Infotainment',
    'News',
    'Kids',
  ];

  const filteredChannels = selectedCategory === 'All'
    ? CHANNELS_DATA
    : CHANNELS_DATA.filter(c => c.category === selectedCategory);

  const toggleRecording = (programId: string) => {
    if (recordedList.includes(programId)) {
      setRecordedList(recordedList.filter(id => id !== programId));
    } else {
      setRecordedList([...recordedList, programId]);
    }
  };

  return (
    <div id="epg-guide-container" className="space-y-6 pb-16">
      
      {/* Header & Filter Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-[#0d1220] p-4 sm:p-6 rounded-3xl border border-white/10 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5 text-cyan-400" />
            <h1 className="text-2xl font-bold text-white tracking-wide">
              Tata Play 7-Day Electronic Program Guide (EPG)
            </h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Browse live broadcast schedules, catch-up programs from the past week, and schedule Cloud DVR recordings
          </p>
        </div>

        {/* Category Pill Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1">
          {categories.map(cat => (
            <button
              key={cat}
              id={`epg-cat-${cat.toLowerCase()}`}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat 
                  ? 'bg-gradient-to-r from-[#e1005a] to-[#ff2a7a] text-white shadow-md' 
                  : 'bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Program Spotlight Card (if any selected) */}
      {selectedProgram && (
        <div className="bg-gradient-to-r from-[#141b2e] to-[#0c101c] p-6 rounded-3xl border-2 border-cyan-400/60 shadow-2xl animate-in fade-in zoom-in-95 duration-200">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded bg-cyan-500/20 text-cyan-300 text-xs font-mono font-bold">
                  {selectedProgram.startTime} - {selectedProgram.endTime} ({selectedProgram.durationMinutes}m)
                </span>
                {selectedProgram.isLive && (
                  <span className="px-2 py-0.5 rounded bg-red-600/30 text-red-400 border border-red-500/40 text-xs font-bold animate-pulse">
                    ● ON AIR NOW
                  </span>
                )}
                {selectedProgram.isCatchup && (
                  <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-xs font-bold">
                    Catch-up Available
                  </span>
                )}
                <span className="text-xs text-slate-400">{selectedProgram.rating}</span>
              </div>
              
              <h2 className="text-2xl font-black text-white">{selectedProgram.title}</h2>
              <p className="text-xs sm:text-sm text-slate-300 max-w-3xl leading-relaxed">{selectedProgram.synopsis}</p>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <button
                id="epg-spotlight-tune-btn"
                onClick={() => {
                  const ch = CHANNELS_DATA.find(c => c.id === selectedProgram.channelId);
                  if (ch) onTuneChannel(ch);
                }}
                className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#e1005a] to-[#ff2a7a] text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-[#e1005a]/30 hover:scale-105 active:scale-95 transition-all"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Tune Channel Now</span>
              </button>

              <button
                id="epg-spotlight-record-btn"
                onClick={() => toggleRecording(selectedProgram.id)}
                className={`px-4 py-2.5 rounded-xl border text-xs font-semibold flex items-center gap-2 transition-all ${
                  recordedList.includes(selectedProgram.id)
                    ? 'bg-emerald-600/20 border-emerald-400 text-emerald-300'
                    : 'bg-white/10 hover:bg-white/20 border-white/15 text-slate-200'
                }`}
              >
                {recordedList.includes(selectedProgram.id) ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Scheduled to Cloud DVR</span>
                  </>
                ) : (
                  <>
                    <Bookmark className="w-4 h-4 text-amber-400" />
                    <span>Record to Cloud DVR</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Main EPG Timeline Grid */}
      <div className="bg-[#0b0f19] rounded-3xl border border-white/10 overflow-hidden shadow-2xl">
        
        {/* Top Timeline Hours Header */}
        <div className="grid grid-cols-[220px_repeat(7,1fr)] bg-[#121827] border-b border-white/10 text-xs font-mono font-bold text-slate-300 sticky top-0 z-20">
          <div className="p-3.5 border-r border-white/10 flex items-center gap-2 text-slate-400">
            <Tv className="w-4 h-4 text-cyan-400" />
            <span>CHANNEL / TIME</span>
          </div>
          {EPG_TIMELINE_SLOTS.map((time, idx) => (
            <div 
              key={time} 
              className={`p-3.5 text-center border-r border-white/5 ${
                idx === 1 ? 'bg-cyan-500/10 text-cyan-300' : ''
              }`}
            >
              <span>{time}</span>
              {idx === 1 && (
                <span className="block text-[9px] text-cyan-400 font-sans uppercase font-bold">Now</span>
              )}
            </div>
          ))}
        </div>

        {/* Channels Rows */}
        <div className="divide-y divide-white/5">
          {filteredChannels.map(ch => {
            const isCurrentlyPlaying = ch.id === currentChannel.id;
            const schedule = EPG_SCHEDULE[ch.id] || [];

            return (
              <div 
                key={ch.id}
                className={`grid grid-cols-[220px_1fr] hover:bg-white/[0.02] transition-colors ${
                  isCurrentlyPlaying ? 'bg-cyan-950/20' : ''
                }`}
              >
                {/* Channel Header (Left) */}
                <div 
                  onClick={() => onTuneChannel(ch)}
                  className="p-3.5 border-r border-white/10 flex items-center justify-between gap-2 cursor-pointer group hover:bg-white/5 transition-colors"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span className="text-2xl shrink-0">{ch.logo}</span>
                    <div className="min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono text-cyan-400 font-bold text-xs">{ch.number}</span>
                        <p className="text-xs font-bold text-white truncate group-hover:text-cyan-300 transition-colors">
                          {ch.name}
                        </p>
                      </div>
                      <span className="text-[10px] text-slate-400">{ch.category}</span>
                    </div>
                  </div>

                  <button 
                    className="p-1 rounded-lg bg-white/5 group-hover:bg-[#e1005a] text-slate-300 group-hover:text-white transition-colors shrink-0"
                    title="Tune Channel"
                  >
                    <Play className="w-3.5 h-3.5 fill-current" />
                  </button>
                </div>

                {/* Program Slots (Right) */}
                <div className="grid grid-cols-7 divide-x divide-white/5 relative p-1 gap-1">
                  {schedule.length > 0 ? (
                    schedule.map((prog) => {
                      const isSelected = selectedProgram?.id === prog.id;
                      const isRecorded = recordedList.includes(prog.id);

                      // Calculate span based on duration
                      const colSpan = prog.durationMinutes >= 120 ? 'col-span-4' : prog.durationMinutes >= 60 ? 'col-span-2' : 'col-span-1';

                      return (
                        <div
                          key={prog.id}
                          id={`epg-slot-${prog.id}`}
                          onClick={() => setSelectedProgram(prog)}
                          className={`${colSpan} p-2.5 rounded-xl border cursor-pointer transition-all flex flex-col justify-between ${
                            prog.isLive 
                              ? 'bg-gradient-to-br from-cyan-950/40 to-slate-900 border-cyan-400/50 hover:border-cyan-400 shadow-md' 
                              : isSelected
                              ? 'bg-white/10 border-white/40 text-white'
                              : 'bg-white/[0.03] hover:bg-white/[0.08] border-white/5 text-slate-300'
                          }`}
                        >
                          <div>
                            <div className="flex items-center justify-between gap-1 mb-1">
                              <span className="text-[10px] font-mono text-cyan-400">
                                {prog.startTime} - {prog.endTime}
                              </span>
                              {prog.isLive && (
                                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                              )}
                              {isRecorded && (
                                <Check className="w-3 h-3 text-emerald-400" />
                              )}
                            </div>
                            <h4 className="font-bold text-xs text-white truncate">{prog.title}</h4>
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-slate-400 mt-1">
                            <span>{prog.genre}</span>
                            <span className="font-mono">{prog.rating}</span>
                          </div>
                        </div>
                      );
                    })
                  ) : (
                    // Default fallback row for channels without full explicit schedule
                    <div 
                      onClick={() => {
                        onTuneChannel(ch);
                      }}
                      className="col-span-7 p-3 rounded-xl bg-white/[0.02] hover:bg-white/[0.05] border border-white/5 flex items-center justify-between cursor-pointer"
                    >
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-white">{ch.currentShow.title}</span>
                          <span className="text-[10px] font-mono text-cyan-400">({ch.currentShow.startTime} - {ch.currentShow.endTime})</span>
                          <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 text-[10px]">On Air</span>
                        </div>
                        <p className="text-[11px] text-slate-400 truncate mt-0.5">{ch.currentShow.synopsis}</p>
                      </div>

                      <span className="text-xs text-cyan-400 font-bold flex items-center gap-1">
                        Watch Live <ChevronRight className="w-3.5 h-3.5" />
                      </span>
                    </div>
                  )}
                </div>

              </div>
            );
          })}
        </div>

      </div>

    </div>
  );
};
