import React, { useState, useRef } from 'react';
import { 
  Upload, 
  Link as LinkIcon, 
  Server, 
  FileText, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Trash2, 
  Sparkles, 
  X,
  Radio,
  Tv,
  HelpCircle,
  FolderOpen
} from 'lucide-react';
import { Channel, XtreamConfig } from '../types';
import { 
  parseM3u, 
  fetchM3uFromUrl, 
  loginXtreamCodes, 
  fetchXtreamChannels,
  SAMPLE_FREE_CHANNELS 
} from '../utils/iptvParser';

interface PlaylistImportModalProps {
  isOpen: boolean;
  onClose: () => void;
  onImportChannels: (channels: Channel[], sourceName: string) => void;
  onClearChannels: () => void;
  currentChannelCount: number;
}

export const PlaylistImportModal: React.FC<PlaylistImportModalProps> = ({
  isOpen,
  onClose,
  onImportChannels,
  onClearChannels,
  currentChannelCount,
}) => {
  const [activeTab, setActiveTab] = useState<'file' | 'url' | 'xtream' | 'paste'>('file');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // M3U URL state
  const [m3uUrl, setM3uUrl] = useState('');

  // Paste state
  const [pasteText, setPasteText] = useState('');

  // Xtream Codes state (persisted from localStorage if available)
  const [xtreamServer, setXtreamServer] = useState(() => localStorage.getItem('tata_xtream_server') || '');
  const [xtreamUser, setXtreamUser] = useState(() => localStorage.getItem('tata_xtream_user') || '');
  const [xtreamPass, setXtreamPass] = useState(() => localStorage.getItem('tata_xtream_pass') || '');
  const [xtreamAccountInfo, setXtreamAccountInfo] = useState<any>(null);

  // Drag-and-drop state
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleResetMessages = () => {
    setErrorMessage(null);
    setSuccessMessage(null);
  };

  // Handle local M3U file upload
  const handleFileChange = (file: File) => {
    handleResetMessages();
    if (!file) return;

    setIsLoading(true);
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const text = e.target?.result as string;
        if (!text) {
          throw new Error('The selected file is empty.');
        }

        const channels = parseM3u(text, file.name);
        if (channels.length === 0) {
          throw new Error('No valid #EXTINF channels found in this file. Please check file format.');
        }

        onImportChannels(channels, file.name);
        setSuccessMessage(`Successfully imported ${channels.length} channels from "${file.name}"!`);
        setTimeout(() => {
          onClose();
        }, 1200);
      } catch (err: any) {
        setErrorMessage(err.message || 'Failed to parse M3U file.');
      } finally {
        setIsLoading(false);
      }
    };

    reader.onerror = () => {
      setErrorMessage('Failed to read the file.');
      setIsLoading(false);
    };

    reader.readAsText(file);
  };

  // Handle M3U URL fetch
  const handleFetchUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    handleResetMessages();
    if (!m3uUrl.trim()) {
      setErrorMessage('Please enter an M3U playlist URL.');
      return;
    }

    setIsLoading(true);
    try {
      const channels = await fetchM3uFromUrl(m3uUrl.trim());
      if (channels.length === 0) {
        throw new Error('No playable channels found in this M3U playlist.');
      }

      onImportChannels(channels, 'Remote M3U URL');
      setSuccessMessage(`Successfully loaded ${channels.length} channels from URL!`);
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to download or parse playlist from URL. Check if URL is reachable.');
    } finally {
      setIsLoading(false);
    }
  };

  // Handle Raw Text Paste
  const handleParsePaste = (e: React.FormEvent) => {
    e.preventDefault();
    handleResetMessages();
    if (!pasteText.trim()) {
      setErrorMessage('Please paste M3U playlist text into the box.');
      return;
    }

    try {
      const channels = parseM3u(pasteText.trim(), 'Pasted Playlist');
      if (channels.length === 0) {
        throw new Error('No valid channels found. Text must contain #EXTINF lines.');
      }

      onImportChannels(channels, 'Pasted Text');
      setSuccessMessage(`Parsed and imported ${channels.length} channels!`);
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to parse pasted M3U text.');
    }
  };

  // Handle Xtream Codes API Login & Load
  const handleXtreamSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    handleResetMessages();

    const server = xtreamServer.trim().replace(/\/+$/, '');
    const user = xtreamUser.trim();
    const pass = xtreamPass.trim();

    if (!server || !user || !pass) {
      setErrorMessage('Please enter Server URL, Username, and Password.');
      return;
    }

    setIsLoading(true);
    try {
      // Step 1: Login & verify credentials
      const loginRes = await loginXtreamCodes(server, user, pass);
      setXtreamAccountInfo(loginRes.userInfo);

      // Save credentials for next time
      localStorage.setItem('tata_xtream_server', server);
      localStorage.setItem('tata_xtream_user', user);
      localStorage.setItem('tata_xtream_pass', pass);

      // Step 2: Fetch Live Streams
      const channels = await fetchXtreamChannels(server, user, pass);
      if (channels.length === 0) {
        throw new Error('Xtream Codes server returned 0 live streams.');
      }

      onImportChannels(channels, `Xtream (${new URL(server).hostname})`);
      setSuccessMessage(`Connected! Loaded ${channels.length} live streams from Xtream Codes.`);
      setTimeout(() => {
        onClose();
      }, 1400);
    } catch (err: any) {
      setErrorMessage(err.message || 'Failed to connect to Xtream Codes server. Check credentials and server port.');
    } finally {
      setIsLoading(false);
    }
  };

  // Load sample free legal channels for instant testing
  const handleLoadSample = () => {
    handleResetMessages();
    onImportChannels(SAMPLE_FREE_CHANNELS, 'Public Legal Broadcasts');
    setSuccessMessage(`Loaded ${SAMPLE_FREE_CHANNELS.length} free public legal test channels (Bloomberg, NASA, Red Bull TV, France 24, Al Jazeera, MP4 4K).`);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <div 
      id="playlist-import-modal-backdrop"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div 
        id="playlist-import-modal-card"
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl bg-[#0e1320] border border-white/15 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Modal Header */}
        <div className="p-5 sm:p-6 border-b border-white/10 bg-gradient-to-r from-[#12192c] to-[#0c101c] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-[#e1005a] to-[#99003c] flex items-center justify-center text-white shadow-lg shadow-[#e1005a]/25">
              <Radio className="w-5 h-5 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-extrabold text-white">Add IPTV Playlist</h2>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                  M3U & XTREME CODES
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Support for all formats: HLS (.m3u8), MPEG-TS (.ts), MP4, and direct live streams
              </p>
            </div>
          </div>
          <button
            id="close-playlist-modal-btn"
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Status / Alert Banner */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-3.5 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-start gap-3 text-red-200 text-xs">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
            <div className="flex-1">{errorMessage}</div>
          </div>
        )}

        {successMessage && (
          <div className="mx-6 mt-4 p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-start gap-3 text-emerald-200 text-xs">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
            <div className="flex-1">{successMessage}</div>
          </div>
        )}

        {/* Tab Selector */}
        <div className="px-6 pt-4 pb-2 border-b border-white/5 flex gap-2 overflow-x-auto">
          <button
            id="tab-m3u-file"
            onClick={() => { setActiveTab('file'); handleResetMessages(); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'file'
                ? 'bg-[#e1005a] text-white shadow-md shadow-[#e1005a]/30'
                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
            }`}
          >
            <Upload className="w-3.5 h-3.5" />
            <span>M3U File Upload</span>
          </button>

          <button
            id="tab-m3u-url"
            onClick={() => { setActiveTab('url'); handleResetMessages(); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'url'
                ? 'bg-[#e1005a] text-white shadow-md shadow-[#e1005a]/30'
                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
            }`}
          >
            <LinkIcon className="w-3.5 h-3.5" />
            <span>M3U URL Link</span>
          </button>

          <button
            id="tab-xtream-codes"
            onClick={() => { setActiveTab('xtream'); handleResetMessages(); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'xtream'
                ? 'bg-[#e1005a] text-white shadow-md shadow-[#e1005a]/30'
                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
            }`}
          >
            <Server className="w-3.5 h-3.5 text-cyan-400" />
            <span>XTREAM CODES API</span>
          </button>

          <button
            id="tab-m3u-paste"
            onClick={() => { setActiveTab('paste'); handleResetMessages(); }}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-all whitespace-nowrap ${
              activeTab === 'paste'
                ? 'bg-[#e1005a] text-white shadow-md shadow-[#e1005a]/30'
                : 'bg-white/5 text-slate-400 hover:text-white hover:bg-white/10'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Paste M3U Text</span>
          </button>
        </div>

        {/* Tab Body */}
        <div className="p-6 flex-1 overflow-y-auto">
          {/* TAB 1: M3U File Upload */}
          {activeTab === 'file' && (
            <div className="space-y-4">
              <input
                type="file"
                ref={fileInputRef}
                accept=".m3u,.m3u8,.txt"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleFileChange(file);
                }}
              />

              <div
                onDragOver={(e) => {
                  e.preventDefault();
                  setIsDragging(true);
                }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setIsDragging(false);
                  const file = e.dataTransfer.files?.[0];
                  if (file) handleFileChange(file);
                }}
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-3xl p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-3 ${
                  isDragging 
                    ? 'border-cyan-400 bg-cyan-500/10' 
                    : 'border-white/20 bg-white/[0.02] hover:border-white/40 hover:bg-white/[0.04]'
                }`}
              >
                <div className="w-14 h-14 rounded-2xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                  <FolderOpen className="w-7 h-7" />
                </div>
                <div>
                  <p className="text-sm font-bold text-white">
                    Drop your <span className="text-cyan-400">.m3u</span> or <span className="text-cyan-400">.m3u8</span> file here
                  </p>
                  <p className="text-xs text-slate-400 mt-1">
                    or click to browse from your computer / phone storage
                  </p>
                </div>
                <div className="flex items-center gap-2 mt-1">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/10 text-slate-300">
                    Supports EXTINF with logos, groups & EPG IDs
                  </span>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-white/5 border border-white/10 text-xs text-slate-400 flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-cyan-400 shrink-0" />
                <span>Channels are parsed directly in the player and persisted locally in your browser session.</span>
              </div>
            </div>
          )}

          {/* TAB 2: M3U URL */}
          {activeTab === 'url' && (
            <form onSubmit={handleFetchUrl} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Playlist URL (.m3u / .m3u8)
                </label>
                <input
                  type="url"
                  required
                  placeholder="http://example.com:8080/get.php?username=...&password=...&type=m3u_plus"
                  value={m3uUrl}
                  onChange={(e) => setM3uUrl(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-2xl px-4 py-3 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors font-mono"
                />
              </div>

              <div className="p-3 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-xs text-cyan-200">
                ⚡ Automatic CORS proxying is active so remote IPTV URLs that block browser requests work seamlessly.
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-[#e1005a] to-[#ff2a7a] text-white font-bold text-sm shadow-lg shadow-[#e1005a]/30 hover:opacity-95 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Downloading & Parsing Playlist...</span>
                  </>
                ) : (
                  <>
                    <LinkIcon className="w-4 h-4" />
                    <span>Download & Load Channels</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* TAB 3: XTREAM CODES API */}
          {activeTab === 'xtream' && (
            <form onSubmit={handleXtreamSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Server URL / Host & Port
                </label>
                <input
                  type="text"
                  required
                  placeholder="http://provider-server.net:8080 or https://..."
                  value={xtreamServer}
                  onChange={(e) => setXtreamServer(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors font-mono"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Username
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Enter username"
                    value={xtreamUser}
                    onChange={(e) => setXtreamUser(e.target.value)}
                    className="w-full bg-black/40 border border-white/15 rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                    Password
                  </label>
                  <input
                    type="password"
                    required
                    placeholder="Enter password"
                    value={xtreamPass}
                    onChange={(e) => setXtreamPass(e.target.value)}
                    className="w-full bg-black/40 border border-white/15 rounded-2xl px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 transition-colors"
                  />
                </div>
              </div>

              {xtreamAccountInfo && (
                <div className="p-3 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-300 space-y-1">
                  <div className="font-bold">Account: {xtreamAccountInfo.username || xtreamUser}</div>
                  <div className="text-[11px] text-emerald-400/80">
                    Status: {xtreamAccountInfo.status} • Max Connections: {xtreamAccountInfo.max_connections || '1'}
                  </div>
                </div>
              )}

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 rounded-2xl bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-bold text-sm shadow-lg shadow-cyan-600/30 hover:opacity-95 transition-opacity disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Connecting to Xtream Codes...</span>
                  </>
                ) : (
                  <>
                    <Server className="w-4 h-4" />
                    <span>Login & Load Xtream Live Streams</span>
                  </>
                )}
              </button>
            </form>
          )}

          {/* TAB 4: Raw Text Paste */}
          {activeTab === 'paste' && (
            <form onSubmit={handleParsePaste} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Paste M3U Contents Here
                </label>
                <textarea
                  rows={7}
                  placeholder={`#EXTM3U\n#EXTINF:-1 tvg-id="ch1" group-title="Sports",Live Sports HD\nhttps://example.com/stream.m3u8`}
                  value={pasteText}
                  onChange={(e) => setPasteText(e.target.value)}
                  className="w-full bg-black/40 border border-white/15 rounded-2xl p-3 text-xs text-white placeholder-slate-600 focus:outline-none focus:border-cyan-400 transition-colors font-mono leading-relaxed"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 rounded-2xl bg-[#e1005a] text-white font-bold text-sm shadow-lg shadow-[#e1005a]/30 hover:opacity-95 transition-opacity flex items-center justify-center gap-2"
              >
                <FileText className="w-4 h-4" />
                <span>Parse Pasted Channels</span>
              </button>
            </form>
          )}
        </div>

        {/* Modal Footer (Instant Testing & Clear Playlist) */}
        <div className="p-5 border-t border-white/10 bg-[#090d16] flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <button
              id="load-sample-channels-btn"
              onClick={handleLoadSample}
              className="px-3 py-1.5 rounded-xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 text-xs font-semibold hover:bg-cyan-500/20 transition-colors flex items-center gap-1.5"
              title="Load free legal public HD/4K channels (Bloomberg, NASA, Red Bull TV, France 24, etc.)"
            >
              <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
              <span>Load Free Legal Sample Streams</span>
            </button>
          </div>

          {currentChannelCount > 0 && (
            <button
              id="clear-playlist-btn"
              onClick={() => {
                if (confirm('Are you sure you want to remove all channels from your playlist?')) {
                  onClearChannels();
                  handleResetMessages();
                  setSuccessMessage('All channels have been removed.');
                }
              }}
              className="px-3 py-1.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs font-semibold hover:bg-red-500/20 transition-colors flex items-center gap-1.5"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear Current Channels ({currentChannelCount})</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
