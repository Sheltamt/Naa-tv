import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  MicOff, 
  X, 
  Search, 
  Sparkles, 
  Play, 
  Tv, 
  Volume2, 
  ArrowRight,
  Zap
} from 'lucide-react';
import { Channel, OttTitle, UserProfile, VoiceSearchResponse } from '../types';
import { OTT_CATALOG } from '../data/ottCatalog';

interface VoiceSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onTuneChannel: (channel: Channel) => void;
  onSelectOttTitle: (title: OttTitle) => void;
  activeProfile: UserProfile;
  channels: Channel[];
}

export const VoiceSearchModal: React.FC<VoiceSearchModalProps> = ({
  isOpen,
  onClose,
  onTuneChannel,
  onSelectOttTitle,
  activeProfile,
  channels,
}) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [voiceResult, setVoiceResult] = useState<VoiceSearchResponse | null>(null);
  const [speechSupported, setSpeechSupported] = useState(true);
  const recognitionRef = useRef<any>(null);

  const sampleVoicePrompts = [
    'Find live cricket match on Star Sports',
    'Show thriller movies on Prime Video',
    'Top trending series on Netflix',
    'Play National Geographic 4K',
    'Tune to Sony PIX 4K',
    'What shows are on Star Plus?',
  ];

  useEffect(() => {
    // Initialize Web Speech API if supported
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-IN'; // Indian English / Global

      recognition.onstart = () => {
        setIsListening(true);
      };

      recognition.onresult = (event: any) => {
        const current = event.resultIndex;
        const text = event.results[current][0].transcript;
        setTranscript(text);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error:', event.error);
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    } else {
      setSpeechSupported(false);
    }

    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch {}
      }
    };
  }, []);

  // When modal opens, start listening automatically
  useEffect(() => {
    if (isOpen) {
      setTranscript('');
      setVoiceResult(null);
      startListening();
    } else {
      stopListening();
    }
  }, [isOpen]);

  const startListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.start();
      } catch (err) {
        // Recognition might already be running
      }
    }
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (err) {}
    }
    setIsListening(false);
  };

  const handleQuerySubmit = async (queryText: string) => {
    if (!queryText.trim()) return;
    setTranscript(queryText);
    stopListening();
    setIsProcessing(true);

    try {
      const res = await fetch('/api/voice-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: queryText,
          activeProfile: activeProfile.name,
        }),
      });

      const json = await res.json();
      if (json.success && json.data) {
        setVoiceResult(json.data);

        // If intent is tune_channel and matches a channel, provide 1.5s preview before auto-tune
        if (json.data.intent === 'tune_channel' && json.data.targetChannelKeyword) {
          const matched = channels.find(c => 
            c.name.toLowerCase().includes(json.data.targetChannelKeyword.toLowerCase()) ||
            c.category.toLowerCase().includes(json.data.targetChannelKeyword.toLowerCase())
          );
          if (matched) {
            setTimeout(() => {
              onTuneChannel(matched);
              onClose();
            }, 1800);
          }
        }
      }
    } catch (err) {
      console.error('Failed to process voice query:', err);
    } finally {
      setIsProcessing(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      id="voice-search-modal"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-xl flex flex-col items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200"
    >
      {/* Close button top right */}
      <button
        id="close-voice-modal-btn"
        onClick={onClose}
        className="absolute top-6 right-6 p-3 rounded-full bg-white/10 hover:bg-white/20 text-slate-300 hover:text-white transition-colors"
        title="Close Voice Search (Esc)"
      >
        <X className="w-6 h-6" />
      </button>

      <div className="w-full max-w-2xl text-center space-y-8">
        
        {/* Animated Google Assistant / Tata Play Voice Ring */}
        <div className="relative inline-flex items-center justify-center">
          {/* Pulsing visualizer rings */}
          {isListening && (
            <>
              <div className="absolute w-44 h-44 rounded-full bg-[#00d2ff]/20 animate-ping" />
              <div className="absolute w-36 h-36 rounded-full bg-[#e1005a]/20 animate-pulse" />
            </>
          )}

          <button
            id="mic-pulse-btn"
            onClick={() => {
              if (isListening) stopListening();
              else startListening();
            }}
            className={`relative w-28 h-28 rounded-full flex items-center justify-center shadow-2xl transition-all ${
              isListening
                ? 'bg-gradient-to-tr from-cyan-400 via-rose-500 to-amber-400 scale-110 shadow-cyan-500/50'
                : 'bg-[#1a2236] hover:bg-[#222c46] border border-white/20'
            }`}
          >
            <div className="w-24 h-24 rounded-full bg-[#090d16] flex items-center justify-center">
              {isListening ? (
                <Mic className="w-10 h-10 text-cyan-300 animate-bounce" />
              ) : (
                <MicOff className="w-10 h-10 text-slate-400" />
              )}
            </div>
          </button>
        </div>

        {/* Status text */}
        <div>
          <h2 className="text-2xl sm:text-3xl font-black text-white tracking-wide">
            {isListening ? 'Listening...' : transcript ? 'Voice Query Recognized' : 'Tata Play Voice Assistant'}
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            {isListening ? 'Speak naturally (e.g. "Find cricket matches" or "Action movies on Netflix")' : 'Tap microphone or pick a quick suggestion below'}
          </p>
        </div>

        {/* Spoken Text Display / Input Box */}
        <div className="bg-[#121828] border-2 border-cyan-400/40 rounded-3xl p-4 sm:p-5 shadow-2xl flex items-center gap-3">
          <Search className="w-5 h-5 text-cyan-400 shrink-0" />
          <input
            type="text"
            id="voice-transcript-input"
            value={transcript}
            onChange={(e) => setTranscript(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') handleQuerySubmit(transcript);
            }}
            placeholder="Speak now or type your query..."
            className="w-full bg-transparent text-white font-medium text-lg placeholder-slate-500 focus:outline-none"
          />
          <button
            id="voice-submit-btn"
            onClick={() => handleQuerySubmit(transcript)}
            disabled={!transcript.trim() || isProcessing}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#e1005a] to-[#ff2a7a] text-white font-bold text-xs shrink-0 disabled:opacity-40 transition-all hover:scale-105"
          >
            {isProcessing ? 'Thinking...' : 'Search'}
          </button>
        </div>

        {/* AI Voice Assistant Response Card (if processed) */}
        {voiceResult && (
          <div className="bg-gradient-to-r from-[#17223b] to-[#101728] border border-cyan-400/60 rounded-3xl p-5 text-left shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="flex items-center gap-2 text-cyan-300 text-xs font-bold uppercase tracking-wider mb-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>Gemini TV Assistant Answer</span>
            </div>

            <p className="text-lg font-bold text-white mb-3">
              "{voiceResult.spokenFeedback}"
            </p>

            {/* Quick Action Preview */}
            <div className="flex items-center justify-between pt-3 border-t border-white/10">
              <span className="text-xs text-slate-300">
                Action: <strong className="text-cyan-300 uppercase">{voiceResult.intent.replace('_', ' ')}</strong>
              </span>

              {voiceResult.targetChannelKeyword && (
                <button
                  onClick={() => {
                    const matched = channels.find(c => 
                      c.name.toLowerCase().includes(voiceResult.targetChannelKeyword!.toLowerCase())
                    );
                    if (matched) {
                      onTuneChannel(matched);
                      onClose();
                    }
                  }}
                  className="px-4 py-2 rounded-xl bg-emerald-500 text-black font-bold text-xs flex items-center gap-1.5 hover:bg-emerald-400 transition-colors shadow"
                >
                  <Play className="w-3.5 h-3.5 fill-current" />
                  <span>Tune {voiceResult.targetChannelKeyword}</span>
                </button>
              )}
            </div>
          </div>
        )}

        {/* Sample Voice Prompts for instant testing */}
        <div className="space-y-2">
          <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Try saying or tap:</p>
          <div className="flex flex-wrap justify-center gap-2">
            {sampleVoicePrompts.map((prompt, i) => (
              <button
                key={i}
                id={`voice-sample-btn-${i}`}
                onClick={() => handleQuerySubmit(prompt)}
                className="px-3.5 py-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-slate-200 hover:text-white transition-all hover:scale-105 active:scale-95"
              >
                "{prompt}"
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
