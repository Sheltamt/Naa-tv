import React, { useState, useEffect, useCallback } from 'react';
import { Channel, UserProfile, StreamTelemetry } from './types';
import { USER_PROFILES } from './data/profiles';
import { NavigationHeader } from './components/NavigationHeader';
import { LivePlayer } from './components/LivePlayer';
import { VoiceSearchModal } from './components/VoiceSearchModal';
import { RemoteControlSimulator } from './components/RemoteControlSimulator';
import { StreamDiagnosticsModal } from './components/StreamDiagnosticsModal';
import { PlaylistImportModal } from './components/PlaylistImportModal';
import { Radio, Tv, Zap, Plus, SlidersHorizontal, Trash2, Eye, EyeOff } from 'lucide-react';

const STORAGE_PLAYLIST_KEY = 'tata_iptv_user_channels';
const STORAGE_REMOTE_ENABLED_KEY = 'tata_iptv_remote_enabled';
const STORAGE_LAST_CHANNEL_KEY = 'tata_iptv_last_channel_id';

export default function App() {
  // Dynamic IPTV Channels (No demo channels by default; user adds M3U or Xtream Codes)
  const [channels, setChannels] = useState<Channel[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PLAYLIST_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error('Failed to load saved channels from localStorage', e);
    }
    return [];
  });

  // Active Channel
  const [currentChannel, setCurrentChannel] = useState<Channel | null>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_PLAYLIST_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          const lastId = localStorage.getItem(STORAGE_LAST_CHANNEL_KEY);
          const found = parsed.find(c => c.id === lastId);
          return found || parsed[0];
        }
      }
    } catch {}
    return null;
  });

  // Selected Profile
  const [activeProfile, setActiveProfile] = useState<UserProfile>(USER_PROFILES[0]);

  // Modals & Overlays
  const [isVoiceSearchOpen, setIsVoiceSearchOpen] = useState(false);
  const [isRemoteOpen, setIsRemoteOpen] = useState(false);
  const [isDiagnosticsOpen, setIsDiagnosticsOpen] = useState(false);
  const [isChannelDrawerOpen, setIsChannelDrawerOpen] = useState(false);
  const [isPlaylistModalOpen, setIsPlaylistModalOpen] = useState(false);

  // Remote Option: Add / Remove Remote state
  const [isRemoteEnabled, setIsRemoteEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem(STORAGE_REMOTE_ENABLED_KEY);
    return saved !== null ? saved === 'true' : true;
  });

  // Live Stream Telemetry State
  const [telemetry, setTelemetry] = useState<StreamTelemetry>({
    latencyMs: 138,
    bufferHealthPercent: '99.6',
    bitrateMbps: '18.9',
    resolution: '3840x2160 (4K UHD 60fps)',
    codec: 'HEVC Main10 / HDR10+',
    audioFormat: 'Dolby Atmos 5.1 (E-AC3 JOC @ 768 kbps)',
    cdnEdge: 'Tata Play Anycast CDN • Edge-08',
    packetLoss: '0.00%',
    jitterMs: 1.8,
    framerate: '60.0 fps (Smooth Motion)',
    drmStatus: 'Hardware Secure',
  });

  // Fetch telemetry from server
  const fetchTelemetry = useCallback(async () => {
    try {
      const res = await fetch('/api/iptv/telemetry');
      if (res.ok) {
        const data = await res.json();
        setTelemetry(data);
      }
    } catch {
      setTelemetry(prev => ({
        ...prev,
        latencyMs: Math.round(135 + Math.random() * 6),
      }));
    }
  }, []);

  useEffect(() => {
    fetchTelemetry();
    const telemetryInterval = setInterval(fetchTelemetry, 5000);
    return () => clearInterval(telemetryInterval);
  }, [fetchTelemetry]);

  // Persist channels when modified
  const handleImportChannels = (newChannels: Channel[], sourceName: string) => {
    setChannels(newChannels);
    try {
      localStorage.setItem(STORAGE_PLAYLIST_KEY, JSON.stringify(newChannels));
    } catch (e) {
      console.warn('Playlist exceeds standard localStorage limit; active in current memory.');
    }
    if (newChannels.length > 0) {
      setCurrentChannel(newChannels[0]);
      localStorage.setItem(STORAGE_LAST_CHANNEL_KEY, newChannels[0].id);
    }
  };

  // Clear playlist
  const handleClearChannels = () => {
    setChannels([]);
    setCurrentChannel(null);
    localStorage.removeItem(STORAGE_PLAYLIST_KEY);
    localStorage.removeItem(STORAGE_LAST_CHANNEL_KEY);
  };

  // Channel selection with persistence
  const handleSelectChannel = (channel: Channel) => {
    setCurrentChannel(channel);
    localStorage.setItem(STORAGE_LAST_CHANNEL_KEY, channel.id);
  };

  // Toggle Remote option (Add / Remove Remote)
  const handleToggleRemoteEnabled = () => {
    setIsRemoteEnabled(prev => {
      const next = !prev;
      localStorage.setItem(STORAGE_REMOTE_ENABLED_KEY, String(next));
      if (!next) setIsRemoteOpen(false);
      return next;
    });
  };

  // Channel stepping via Remote CH +/- or Arrow Keys
  const handleChannelStep = useCallback((step: 1 | -1) => {
    if (channels.length === 0 || !currentChannel) return;
    const idx = channels.findIndex(c => c.id === currentChannel.id);
    const nextIdx = (idx + step + channels.length) % channels.length;
    handleSelectChannel(channels[nextIdx]);
  }, [channels, currentChannel]);

  // Direct Channel Number Punch
  const handleNumberPress = useCallback((numStr: string) => {
    if (channels.length === 0) return;
    const num = parseInt(numStr, 10);
    const matched = channels.find(c => c.number === num || c.number.toString().startsWith(numStr));
    if (matched) {
      handleSelectChannel(matched);
    }
  }, [channels]);

  // Remote D-Pad Navigation Handler
  const handleRemoteNavigate = (action: 'up' | 'down' | 'left' | 'right' | 'select' | 'back' | 'home') => {
    if (action === 'back' || action === 'home') {
      if (isVoiceSearchOpen) setIsVoiceSearchOpen(false);
      else if (isDiagnosticsOpen) setIsDiagnosticsOpen(false);
      else if (isChannelDrawerOpen) setIsChannelDrawerOpen(false);
      else if (isPlaylistModalOpen) setIsPlaylistModalOpen(false);
    } else if (action === 'up') {
      handleChannelStep(1);
    } else if (action === 'down') {
      handleChannelStep(-1);
    } else if (action === 'select') {
      setIsChannelDrawerOpen(prev => !prev);
    }
  };

  // Keyboard shortcut listener for authentic Android TV remote feeling
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      if (e.key === 'v' || e.key === 'V') {
        setIsVoiceSearchOpen(prev => !prev);
      } else if (e.key === 'r' || e.key === 'R') {
        if (isRemoteEnabled) {
          setIsRemoteOpen(prev => !prev);
        }
      } else if (e.key === 'i' || e.key === 'I') {
        setIsDiagnosticsOpen(prev => !prev);
      } else if (e.key === 'p' || e.key === 'P') {
        setIsPlaylistModalOpen(prev => !prev);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        handleChannelStep(1);
      } else if (e.key === 'ArrowDown') {
        e.preventDefault();
        handleChannelStep(-1);
      } else if (e.key === 'Escape') {
        setIsVoiceSearchOpen(false);
        setIsDiagnosticsOpen(false);
        setIsChannelDrawerOpen(false);
        setIsPlaylistModalOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [handleChannelStep, isRemoteEnabled]);

  return (
    <div className="min-h-screen bg-[#080b11] text-slate-100 flex flex-col font-['Outfit',sans-serif]">
      
      {/* Top Android TV IPTV Header */}
      <NavigationHeader
        currentChannel={currentChannel}
        channelsCount={channels.length}
        activeProfile={activeProfile}
        onProfileChange={setActiveProfile}
        onOpenVoiceSearch={() => setIsVoiceSearchOpen(true)}
        onToggleRemote={() => isRemoteEnabled && setIsRemoteOpen(!isRemoteOpen)}
        isRemoteOpen={isRemoteOpen}
        isRemoteEnabled={isRemoteEnabled}
        onToggleRemoteEnabled={handleToggleRemoteEnabled}
        onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
        currentLatency={telemetry.latencyMs}
        onToggleChannelList={() => setIsChannelDrawerOpen(!isChannelDrawerOpen)}
        isChannelListOpen={isChannelDrawerOpen}
        onOpenPlaylistModal={() => setIsPlaylistModalOpen(true)}
      />

      {/* Main Dedicated IPTV Player Stage */}
      <main className="flex-1 max-w-[1920px] w-full mx-auto px-4 lg:px-8 py-4 flex flex-col justify-between">
        
        {/* The Live IPTV Player */}
        <div className="w-full">
          <LivePlayer
            currentChannel={currentChannel}
            channels={channels}
            onSelectChannel={handleSelectChannel}
            isPiP={false}
            onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
            currentLatency={telemetry.latencyMs}
            isChannelDrawerOpen={isChannelDrawerOpen}
            onToggleChannelDrawer={() => setIsChannelDrawerOpen(!isChannelDrawerOpen)}
            onOpenImportModal={() => setIsPlaylistModalOpen(true)}
            isRemoteOpen={isRemoteOpen}
            isRemoteEnabled={isRemoteEnabled}
            onToggleRemote={() => isRemoteEnabled && setIsRemoteOpen(!isRemoteOpen)}
            onRemoveRemote={() => {
              setIsRemoteOpen(false);
              setIsRemoteEnabled(false);
              localStorage.setItem(STORAGE_REMOTE_ENABLED_KEY, 'false');
            }}
            onAddRemote={() => {
              setIsRemoteEnabled(true);
              setIsRemoteOpen(true);
              localStorage.setItem(STORAGE_REMOTE_ENABLED_KEY, 'true');
            }}
          />
        </div>

        {/* Quick Channel Zapper Carousel Strip (Shown when channels exist) */}
        {channels.length > 0 && (
          <div className="space-y-3 mt-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  Fast IPTV Channel Zap ({channels.length} Channels Loaded)
                </h2>
              </div>
              <div className="flex items-center gap-2">
                <button
                  id="header-open-playlist-btn"
                  onClick={() => setIsPlaylistModalOpen(true)}
                  className="text-xs text-slate-300 hover:text-white px-2.5 py-1 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 flex items-center gap-1 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Add More Streams</span>
                </button>
                <button
                  id="open-channel-guide-btn"
                  onClick={() => setIsChannelDrawerOpen(true)}
                  className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 transition-colors"
                >
                  <span>Channel Guide (C)</span> &rarr;
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 lg:grid-cols-10 gap-2 max-h-56 overflow-y-auto custom-scrollbar p-0.5">
              {channels.map((ch) => {
                const isSelected = currentChannel && ch.id === currentChannel.id;
                return (
                  <button
                    key={ch.id}
                    id={`quick-zap-${ch.id}`}
                    onClick={() => handleSelectChannel(ch)}
                    className={`p-2.5 rounded-2xl border text-left transition-all flex flex-col justify-between h-24 ${
                      isSelected
                        ? 'bg-[#e1005a]/25 border-cyan-400 text-white shadow-lg shadow-cyan-500/10 ring-2 ring-cyan-400/40 scale-[1.02]'
                        : 'bg-[#101524]/80 border-white/10 text-slate-300 hover:bg-white/10 hover:border-white/20'
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <div className="w-7 h-7 rounded-lg bg-black/40 flex items-center justify-center text-sm overflow-hidden shrink-0">
                        {ch.logo.startsWith('http') ? (
                          <img 
                            src={ch.logo} 
                            alt={ch.name} 
                            className="w-full h-full object-contain"
                            crossOrigin="anonymous"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                        ) : (
                          ch.logo || '📺'
                        )}
                      </div>
                      <span className="font-mono text-cyan-400 font-extrabold text-[11px]">
                        {ch.number}
                      </span>
                    </div>
                    <div>
                      <div className="flex items-center justify-between">
                        <p className="text-xs font-bold text-white truncate">{ch.name}</p>
                        {isSelected && <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shrink-0 ml-1" />}
                      </div>
                      <p className="text-[10px] text-slate-400 truncate mt-0.5">
                        {ch.currentShow?.title || ch.category}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Keyboard & Remote Navigation Shortcuts Bar */}
        <div className="mt-4 p-3 rounded-2xl bg-[#0d121f] border border-white/10 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <Tv className="w-4 h-4 text-cyan-400" />
            <span className="font-semibold text-slate-300">Android TV Controls:</span>
          </div>
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 text-[11px]">
            <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">▲ / ▼</kbd> Zap Channel</span>
            <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">0-9</kbd> Direct Tune</span>
            <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">Space</kbd> Play/Pause</span>
            <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">M</kbd> Mute</span>
            <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">C</kbd> Channels</span>
            <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">V</kbd> Voice Search</span>
            <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">P</kbd> Playlist (M3U / Xtream)</span>
            {isRemoteEnabled && (
              <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">R</kbd> Remote</span>
            )}
            <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">I</kbd> Telemetry</span>
            <span><kbd className="px-1.5 py-0.5 rounded bg-white/10 text-white font-mono">F</kbd> Fullscreen</span>
          </div>
        </div>

      </main>

      {/* Virtual Android TV Remote Control Overlay (Only if Remote Option is Enabled) */}
      {isRemoteEnabled && (
        <RemoteControlSimulator
          isOpen={isRemoteOpen}
          onClose={() => setIsRemoteOpen(false)}
          onRemoveRemote={() => {
            setIsRemoteOpen(false);
            setIsRemoteEnabled(false);
            localStorage.setItem(STORAGE_REMOTE_ENABLED_KEY, 'false');
          }}
          onNavigate={handleRemoteNavigate}
          onVoiceSearch={() => setIsVoiceSearchOpen(true)}
          onNumberPress={handleNumberPress}
          onChannelStep={handleChannelStep}
          onVolumeStep={() => {}}
          onToggleMute={() => {}}
          onOpenEpg={() => setIsChannelDrawerOpen(true)}
          onOpenDiagnostics={() => setIsDiagnosticsOpen(true)}
          onQuickApp={(app) => {
            if (app === 'live' || app === 'binge') {
              setIsChannelDrawerOpen(true);
            }
          }}
        />
      )}

      {/* Playlist Import Modal (M3U File, M3U URL, Xtream Codes API, Paste Text) */}
      <PlaylistImportModal
        isOpen={isPlaylistModalOpen}
        onClose={() => setIsPlaylistModalOpen(false)}
        onImportChannels={handleImportChannels}
        onClearChannels={handleClearChannels}
        currentChannelCount={channels.length}
      />

      {/* Voice Search / Google Assistant Modal */}
      <VoiceSearchModal
        isOpen={isVoiceSearchOpen}
        onClose={() => setIsVoiceSearchOpen(false)}
        onTuneChannel={(ch) => {
          handleSelectChannel(ch);
          setIsVoiceSearchOpen(false);
        }}
        onSelectOttTitle={() => {}}
        activeProfile={activeProfile}
        channels={channels}
      />

      {/* Ultra Low-Latency Stream Diagnostics Modal */}
      <StreamDiagnosticsModal
        isOpen={isDiagnosticsOpen}
        onClose={() => setIsDiagnosticsOpen(false)}
        telemetry={telemetry}
        onRefreshTelemetry={fetchTelemetry}
      />

      {/* Footer Status Bar */}
      <footer className="border-t border-white/10 bg-[#06080e] px-4 lg:px-8 py-2.5 text-xs text-slate-400">
        <div className="max-w-[1920px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-3">
            <span className="font-bold text-white">Tata Play IPTV Player</span>
            <span className="text-white/20">•</span>
            <span className="text-emerald-400 font-mono">Anycast Latency: {telemetry.latencyMs}ms</span>
            <span className="text-white/20">•</span>
            <span className="text-slate-400">Formats: HLS (.m3u8), MPEG-TS (.ts), MP4</span>
            <span className="text-white/20">•</span>
            <span>Remote: {isRemoteEnabled ? 'Enabled' : 'Removed'}</span>
          </div>

          <div className="flex items-center gap-3 text-[11px] text-slate-400">
            <button
              onClick={handleToggleRemoteEnabled}
              className="hover:text-white underline flex items-center gap-1"
              title="Add or remove the virtual remote"
            >
              {isRemoteEnabled ? <EyeOff className="w-3 h-3 text-red-400" /> : <Eye className="w-3 h-3 text-emerald-400" />}
              <span>{isRemoteEnabled ? 'Remove Remote Option' : 'Add Remote Option'}</span>
            </button>
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>Hardware HEVC Decoder</span>
          </div>
        </div>
      </footer>

    </div>
  );
}
