import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialized Gemini AI client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return null;
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// Health check
app.get("/api/health", (_req, res) => {
  res.json({
    status: "ok",
    service: "Tata Play IPTV Android TV Backend",
    timestamp: new Date().toISOString(),
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
  });
});

// Low-latency IPTV real-time telemetry stats
app.get("/api/iptv/telemetry", (_req, res) => {
  // Live low-latency stream simulation stats with minor realistic fluctuations
  const baseLatency = 138;
  const jitter = (Math.random() * 4 - 2).toFixed(1);
  const latency = Math.round(baseLatency + parseFloat(jitter));
  
  res.json({
    latencyMs: latency,
    bufferHealthPercent: (99.2 + Math.random() * 0.7).toFixed(1),
    bitrateMbps: (17.8 + Math.random() * 1.6).toFixed(1),
    resolution: "3840x2160 (4K UHD 60fps)",
    codec: "HEVC Main10 / HDR10+",
    audioFormat: "Dolby Atmos 5.1 (E-AC3 JOC @ 768 kbps)",
    cdnEdge: "Tata Play Anycast CDN • BOM-Edge-08",
    packetLoss: "0.00%",
    jitterMs: Math.abs(parseFloat(jitter)),
    framerate: "60.0 fps (Smooth Motion)",
    drmStatus: "Widevine L1 Hardware Secure",
  });
});

// M3U Playlist Proxy (Bypasses CORS restrictions on remote playlist URLs)
app.get("/api/iptv/m3u-proxy", async (req, res) => {
  const targetUrl = req.query.url as string;
  if (!targetUrl || (!targetUrl.startsWith("http://") && !targetUrl.startsWith("https://"))) {
    return res.status(400).json({ error: "Invalid playlist URL. Must begin with http:// or https://" });
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    const response = await fetch(targetUrl, {
      signal: controller.signal,
      headers: {
        "User-Agent": "IPTVSmartersPro/3.1.5 (Android TV; Linux)",
        "Accept": "*/*",
      },
    });
    clearTimeout(timeout);

    if (!response.ok) {
      return res.status(response.status).json({ 
        error: `Remote playlist server responded with status: ${response.status} ${response.statusText}` 
      });
    }

    const playlistText = await response.text();
    res.setHeader("Content-Type", "text/plain; charset=utf-8");
    res.setHeader("Access-Control-Allow-Origin", "*");
    res.send(playlistText);
  } catch (error: any) {
    console.error("M3U proxy error:", error);
    res.status(502).json({ error: `Failed to download M3U playlist: ${error.message || error}` });
  }
});

// Xtream Codes Authentication & Profile Check
app.post("/api/iptv/xtream/login", async (req, res) => {
  try {
    const { serverUrl, username, password } = req.body;
    if (!serverUrl || !username || !password) {
      return res.status(400).json({ error: "Server URL, Username, and Password are required." });
    }

    const cleanServer = serverUrl.replace(/\/+$/, "");
    const authUrl = `${cleanServer}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`;

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);

    const response = await fetch(authUrl, {
      signal: controller.signal,
      headers: {
        "User-Agent": "IPTVSmartersPro/3.1.5 (Android TV; Linux)",
        "Accept": "application/json, */*",
      },
    });
    clearTimeout(timeout);

    if (!response.ok) {
      return res.status(response.status).json({ error: `Xtream Codes server returned HTTP ${response.status}` });
    }

    const data = await response.json();
    if (!data || data.user_info?.auth === 0 || data.user_info?.status === "Disabled") {
      return res.status(401).json({ 
        error: data?.user_info?.message || "Invalid Xtream Codes username, password, or expired account.",
        data
      });
    }

    res.json({
      success: true,
      userInfo: data.user_info,
      serverInfo: data.server_info,
    });
  } catch (error: any) {
    console.error("Xtream Codes login error:", error);
    res.status(502).json({ error: `Unable to connect to Xtream Codes server: ${error.message || error}` });
  }
});

// Xtream Codes Fetch Streams (Live Streams, Categories, etc.)
app.post("/api/iptv/xtream/streams", async (req, res) => {
  try {
    const { serverUrl, username, password, action = "get_live_streams", categoryId } = req.body;
    if (!serverUrl || !username || !password) {
      return res.status(400).json({ error: "Missing required Xtream credentials" });
    }

    const cleanServer = serverUrl.replace(/\/+$/, "");
    let queryUrl = `${cleanServer}/player_api.php?username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}&action=${action}`;
    if (categoryId) {
      queryUrl += `&category_id=${encodeURIComponent(categoryId)}`;
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 20000);

    const response = await fetch(queryUrl, {
      signal: controller.signal,
      headers: {
        "User-Agent": "IPTVSmartersPro/3.1.5 (Android TV; Linux)",
        "Accept": "application/json, */*",
      },
    });
    clearTimeout(timeout);

    if (!response.ok) {
      return res.status(response.status).json({ error: `Xtream server returned HTTP ${response.status}` });
    }

    const data = await response.json();
    res.json({
      success: true,
      data: Array.isArray(data) ? data : [],
    });
  } catch (error: any) {
    console.error("Xtream Codes streams error:", error);
    res.status(502).json({ error: `Failed to fetch Xtream streams: ${error.message || error}` });
  }
});

// Stream Proxy for cross-origin restricted HLS / TS segments
app.get("/api/iptv/stream-proxy", async (req, res) => {
  const streamUrl = req.query.url as string;
  if (!streamUrl || (!streamUrl.startsWith("http://") && !streamUrl.startsWith("https://"))) {
    return res.status(400).send("Invalid stream URL");
  }

  try {
    const response = await fetch(streamUrl, {
      headers: {
        "User-Agent": "VLC/3.0.18 LibVLC/3.0.18",
        "Accept": "*/*",
      },
    });

    res.setHeader("Access-Control-Allow-Origin", "*");
    res.setHeader("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS");
    if (response.headers.get("content-type")) {
      res.setHeader("Content-Type", response.headers.get("content-type")!);
    }

    if (!response.body) {
      return res.status(response.status).send();
    }

    // Node 18+ web stream to node readable
    const { Readable } = await import("stream");
    // @ts-ignore
    const nodeStream = Readable.fromWeb(response.body);
    nodeStream.pipe(res);
  } catch (err: any) {
    res.status(502).send(`Proxy error: ${err.message}`);
  }
});

// Voice Search intent & natural language AI processing
app.post("/api/voice-search", async (req, res) => {
  try {
    const { query, activeProfile = "Family" } = req.body;
    if (!query || typeof query !== "string") {
      return res.status(400).json({ error: "Missing search query" });
    }

    const ai = getGeminiClient();
    if (ai) {
      try {
        const prompt = `You are the Tata Play Android TV Box Voice Assistant (powered by Google Assistant & Tata Play Binge).
The user just spoke this voice search query: "${query}"
Active User Profile: "${activeProfile}".

Tata Play features both Live IPTV channels and external OTT platforms (Netflix, Amazon Prime Video, Disney+ Hotstar, SonyLIV, Zee5, Apple TV+, YouTube).

Analyze the user's intent and respond with strict JSON matching this schema:
{
  "spokenFeedback": "Short, friendly TV assistant response (e.g. 'Tuning to Star Sports 1 HD for India vs Australia Cricket' or 'Here are top action thrillers on Prime Video and Netflix')",
  "intent": "tune_channel" | "filter_ott" | "search_titles" | "general_recommendation",
  "targetChannelKeyword": "channel name if they asked for a channel, else null",
  "targetOttPlatform": "netflix" | "prime" | "hotstar" | "sonyliv" | "zee5" | "all" | null,
  "genre": "action" | "sports" | "comedy" | "drama" | "news" | "movies" | null,
  "suggestedQuery": "cleaned search term"
}
Output only raw JSON without markdown code fences.`;

        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
          },
        });

        const rawText = response.text?.trim() || "{}";
        const parsed = JSON.parse(rawText);
        return res.json({
          success: true,
          source: "gemini-3.8-flash",
          data: parsed,
        });
      } catch (err) {
        console.warn("Gemini voice search failed, falling back to heuristic parser:", err);
      }
    }

    // Heuristic fallback for offline/no-key mode
    const qLower = query.toLowerCase();
    let intent = "search_titles";
    let targetChannelKeyword: string | null = null;
    let targetOttPlatform: string | null = null;
    let spokenFeedback = `Searching for "${query}" across Tata Play Live TV & Streaming Apps...`;

    if (qLower.includes("star sports") || qLower.includes("cricket") || qLower.includes("football")) {
      intent = "tune_channel";
      targetChannelKeyword = "Star Sports";
      spokenFeedback = "Tuning to Star Sports 1 HD live broadcast.";
    } else if (qLower.includes("netflix")) {
      intent = "filter_ott";
      targetOttPlatform = "netflix";
      spokenFeedback = "Opening top streaming content available on Netflix.";
    } else if (qLower.includes("prime") || qLower.includes("amazon")) {
      intent = "filter_ott";
      targetOttPlatform = "prime";
      spokenFeedback = "Showing top movies and series on Prime Video.";
    } else if (qLower.includes("news") || qLower.includes("ndtv") || qLower.includes("aaj tak")) {
      intent = "tune_channel";
      targetChannelKeyword = "News";
      spokenFeedback = "Opening live news channels.";
    } else if (qLower.includes("movie") || qLower.includes("cinema")) {
      intent = "search_titles";
      spokenFeedback = "Here are trending blockbuster movies on Live TV, Netflix, and Prime.";
    }

    res.json({
      success: true,
      source: "local-heuristic",
      data: {
        spokenFeedback,
        intent,
        targetChannelKeyword,
        targetOttPlatform,
        genre: null,
        suggestedQuery: query,
      },
    });
  } catch (error: any) {
    console.error("Voice search endpoint error:", error);
    res.status(500).json({ error: "Failed to process voice search query" });
  }
});

// Personalized recommendations engine
app.post("/api/recommendations", async (req, res) => {
  try {
    const { profileName = "Family", currentMood = "Trending Hits", recentHistory = [] } = req.body;
    const ai = getGeminiClient();

    if (ai) {
      try {
        const prompt = `You are the Tata Play Binge Personalized Recommendation Engine for an Android TV Box in India.
Current Profile: "${profileName}"
Mood/Context: "${currentMood}"
Recent Viewing History: ${JSON.stringify(recentHistory)}

Generate 4 ultra-curated entertainment recommendations that unify Indian Live TV channels with OTT services (Netflix, Prime Video, Disney+ Hotstar, SonyLIV).
Return valid JSON:
[
  {
    "title": "Title of show/movie/match",
    "platform": "Netflix" | "Prime Video" | "Disney+ Hotstar" | "SonyLIV" | "Tata Play Live TV",
    "type": "Live Match" | "Movie" | "Series",
    "genre": "Genre",
    "rating": "IMDb 8.6 or Rotten Tomatoes 94%",
    "badge": "4K HDR" | "Live Now" | "Dolby Atmos" | "Trending #1",
    "reason": "Personalized 1-sentence reason why this matches the profile",
    "channelNumber": 401 (if live channel, else null)
  }
]
Return ONLY JSON without markdown backticks.`;

        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: prompt,
          config: {
            responseMimeType: "application/json",
          },
        });

        const recommendations = JSON.parse(response.text?.trim() || "[]");
        return res.json({
          success: true,
          source: "gemini-3.8-flash",
          recommendations,
        });
      } catch (err) {
        console.warn("Gemini recommendation failed, using curated backup:", err);
      }
    }

    // Default smart recommendations
    const curated = [
      {
        title: "India vs Australia - 3rd ODI Live",
        platform: "Tata Play Live TV",
        type: "Live Match",
        genre: "Cricket / Sports",
        rating: "Live 4K",
        badge: "Ultra Low Latency 140ms",
        reason: "Trending live nationwide with Dolby 5.1 multi-angle audio",
        channelNumber: 401,
      },
      {
        title: "The Railway Men",
        platform: "Netflix",
        type: "Series",
        genre: "Historical Drama",
        rating: "IMDb 8.5",
        badge: "4K Dolby Vision",
        reason: "Based on your interest in gripping true Indian drama stories",
        channelNumber: null,
      },
      {
        title: "Mirzapur - Season 3",
        platform: "Prime Video",
        type: "Series",
        genre: "Crime Thriller",
        rating: "IMDb 8.5",
        badge: "Tata Play Binge Included",
        reason: "Top trending on Prime Video India with seamless 1-click playback",
        channelNumber: null,
      },
      {
        title: "Star Gold Cinema Premiere: Fighter 4K",
        platform: "Tata Play Live TV",
        type: "Movie",
        genre: "Action / Thriller",
        rating: "4K HDR",
        badge: "Broadcast Premiere",
        reason: "Air-to-air action spectacle streaming in native 50fps broadcast quality",
        channelNumber: 504,
      },
    ];

    res.json({
      success: true,
      source: "curated",
      recommendations: curated,
    });
  } catch (error: any) {
    console.error("Recommendations error:", error);
    res.status(500).json({ error: "Failed to load recommendations" });
  }
});

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Tata Play IPTV Android TV server listening on http://localhost:${PORT}`);
  });
}

startServer();
